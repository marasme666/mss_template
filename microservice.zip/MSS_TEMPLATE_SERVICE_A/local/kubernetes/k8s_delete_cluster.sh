#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_delete_cluster.sh ---"
echo "-------------------------------"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

#----------------------------------------------------------
# SET UP GLOBAL INFRASTRUCTURE
#----------------------------------------------------------
kind delete cluster --name ${CLUSTER_NAME}-cluster || true
