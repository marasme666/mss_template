#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_infra_gl.sh ---"
echo "-------------------------------"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${2:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
GL_HELM_RELEASE_INFRA_NAME=infra-gl

#----------------------------------------------------------
# SET UP GLOBAL INFRASTRUCTURE
#----------------------------------------------------------

echo "--- CREATE K8S CLUSTER ---"

if [ ${CLUSTER_NAME} == "local" ]; then

  kind create cluster --config  kind-cluster-local.yaml  --name ${CLUSTER_NAME}-cluster  || exit 0

else

  #kind create cluster --config  kind-cluster-microservice.yaml  --name ${CLUSTER_NAME}-cluster || exit 0
  kind create cluster --name ${CLUSTER_NAME}-cluster || exit 0

fi

kubectl config use-context $KIND_CLUSTER_NAME


echo "--- KUBERNETES CONFIG APPLICATION ---"

# INGRESS NGINX CONTROLLER
kubectl --context=$KIND_CLUSTER_NAME  apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/master/deploy/static/provider/kind/deploy.yaml

# HELM OPERATOR
kubectl --context=$KIND_CLUSTER_NAME  apply --namespace default -f https://raw.githubusercontent.com/fluxcd/helm-operator/master/deploy/crds.yaml

echo "--- HELM INSTALL DEPENDENCY ---"

helm --kube-context $KIND_CLUSTER_NAME dependency build ./chart

helm --kube-context $KIND_CLUSTER_NAME install ${GL_HELM_RELEASE_INFRA_NAME} ./chart

sleep 20

echo "--- SET UP VAULT PERMISSIONS ---"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=Ready pod/${GL_HELM_RELEASE_INFRA_NAME}-vault-0 --timeout=${DEFAULT_TIMEOUT}

kubectl --context=$KIND_CLUSTER_NAME  exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- vault auth enable kubernetes

SECRET_KUBERNETES_TOKEN=$(kubectl --context=$KIND_CLUSTER_NAME  exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- cat /var/run/secrets/kubernetes.io/serviceaccount/token)

SECRET_KUBERNETES_CERTIFICATE=$(kubectl --context=$KIND_CLUSTER_NAME  exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- cat /var/run/secrets/kubernetes.io/serviceaccount/ca.crt)

kubectl --context=$KIND_CLUSTER_NAME  exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- vault write auth/kubernetes/config kubernetes_host="https://kubernetes.default.svc" token_reviewer_jwt=${SECRET_KUBERNETES_TOKEN} kubernetes_ca_cert=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt issuer="https://kubernetes.default.svc.cluster.local"


echo "--- INIT GITEA REPOSITORY---"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=Ready pod -l app.kubernetes.io/name=gitea --timeout=${DEFAULT_TIMEOUT}

GITEA_POD_NAME=$(kubectl --context=$KIND_CLUSTER_NAME  get pods --selector=app.kubernetes.io/instance=${GL_HELM_RELEASE_INFRA_NAME},app.kubernetes.io/name=gitea --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')

kubectl --context=$KIND_CLUSTER_NAME  exec -it pod/${GITEA_POD_NAME}  -- git config --global user.email "gitea@gitea.com"

kubectl --context=$KIND_CLUSTER_NAME  exec -it pod/${GITEA_POD_NAME}  -- git config --global user.name "gitea"


echo "--- SET UP GITEA REPOSITORY FOR MICROSERVICE---"

GITEA_POD_NAME=$(kubectl --context=$KIND_CLUSTER_NAME  get pods --selector=app.kubernetes.io/instance=${GL_HELM_RELEASE_INFRA_NAME},app.kubernetes.io/name=gitea --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')

kubectl --context=$KIND_CLUSTER_NAME  exec -it pod/${GITEA_POD_NAME} -- curl -X POST 'http://gitea:password@localhost:3000/api/v1/user/repos' -H 'Accept: application/json' -H 'Content-Type: application/json' -d '{ "auto_init": false, "default_branch": "master", "description": "microservice", "gitignores": "", "issue_labels": "", "license": "", "name": "microservice", "private": false, "readme": "microservice", "template": false, "trust_model": "default" }' 



echo "--- SET UP GITEA REPOSITORY FOR GITOPS---"

GITEA_POD_NAME=$(kubectl --context=$KIND_CLUSTER_NAME  get pods --selector=app.kubernetes.io/instance=${GL_HELM_RELEASE_INFRA_NAME},app.kubernetes.io/name=gitea --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')

kubectl --context=$KIND_CLUSTER_NAME  exec -it pod/${GITEA_POD_NAME} -- curl -X POST 'http://gitea:password@localhost:3000/api/v1/user/repos' -H 'Accept: application/json' -H 'Content-Type: application/json' -d '{ "auto_init": false, "default_branch": "master", "description": "gitops", "gitignores": "", "issue_labels": "", "license": "", "name": "gitops", "private": false, "readme": "gitops", "template": false, "trust_model": "default" }' 

