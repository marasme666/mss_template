#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: test_script.sh ---"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

: ${PROTOCOL=http}
: ${HOST=localhost}
: ${PORT=3333}
: ${URLPATH=}

#----------------------------------------------------------
#  HELP FUNCTIONS
#----------------------------------------------------------

function assertCurl() {

  local expectedHttpCode=$1
  local curlCmd="$2 -w \"%{http_code}\""
  local result=$(eval $curlCmd)
  local httpCode="${result:(-3)}"
  RESPONSE='' && (( ${#result} > 3 )) && RESPONSE="${result%???}"

  if [ "$httpCode" = "$expectedHttpCode" ]
  then
    if [ "$httpCode" = "200" ]
    then
      echo "Test OK (HTTP Code: $httpCode)"
    else
      echo "Test OK (HTTP Code: $httpCode, $RESPONSE)"
    fi
  else
    echo  "Test FAILED, EXPECTED HTTP Code: $expectedHttpCode, GOT: $httpCode, WILL ABORT!"
    echo  "- Failing command: $curlCmd"
    echo  "- Response Body: $RESPONSE"
    exit 1
  fi
}

function assertEqual() {

  local expected=$1
  local actual=$2

  if [ "$actual" = "$expected" ]
  then
    echo "Test OK (actual value: $actual)"
  else
    echo "Test FAILED, EXPECTED VALUE: $expected, ACTUAL VALUE: $actual, WILL ABORT"
    exit 1
  fi
}

function testUrl() {
  url=$@
  if $url -ks -f -o /dev/null
  then
    return 0
  else
    return 1
  fi;
}

function waitForService() {
  url=$@
  echo -n "Wait for: $url... "
  n=0
  until testUrl $url
  do
    n=$((n + 1))
    if [[ $n == 100 ]]
    then
      echo " Give up"
      exit 1
    else
      sleep 3
      echo -n ", retry #$n "
    fi
  done
  echo "DONE, continues..."
}

#----------------------------------------------------------
#  START END TO END TESTING
#----------------------------------------------------------

echo "----------------------------------------------------------"
echo "--- START TESTING ---"
echo "----------------------------------------------------------"

# Wait for microservice to be ready
waitForService curl $PROTOCOL://$HOST:$PORT/actuator/health


#----------------------------------------------------------
#  CHAOS TESTING START
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- KILL APPLICATION TESTING ---"
echo "----------------------------------------------------------"



echo "--- ENABLE CHAOS MONKEY IN APPLICATION ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/enable\" -H 'Content-Type: application/json' "


echo "--- ENABLE CHAOS MONKEY WATCHERS ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/watchers\" -H 'Content-Type: application/json' -d '{ \"controller\":false, \"restController\":true, \"service\":false, \"repository\":false, \"component\":false, \"restTemplate\":false, \"webClient\":false, \"actuatorHealth\":false}'"


echo "--- ENABLE CHAOS MONKEY ASSAULTAS ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/assaults\" -H 'Content-Type: application/json' -d '{ \"level\":1, \"latencyActive\":false, \"exceptionsActive\":false, \"killApplicationActive\":true, \"memoryActive\":false, \"cpuActive\":false }'"

echo "--- START CHAOS MONKEY RUNTIME ATTACK ---"
curl -X POST "$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/assaults/runtime/attack" -H 'Content-Type: application/json' || true

waitForService curl $PROTOCOL://$HOST:$PORT/actuator/health

echo "--- TEST REGULAR REQUEST ALL ROWS ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH\""



echo "----------------------------------------------------------"
echo "--- LATENCY APPLICATION TESTING ---"
echo "----------------------------------------------------------"


echo "--- ENABLE CHAOS MONKEY IN APPLICATION ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/enable\" -H 'Content-Type: application/json' "


echo "--- ENABLE CHAOS MONKEY WATCHERS ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/watchers\" -H 'Content-Type: application/json' -d '{ \"controller\":false, \"restController\":true, \"service\":false, \"repository\":false, \"component\":false, \"restTemplate\":false, \"webClient\":false, \"actuatorHealth\":false}'"


echo "--- ENABLE CHAOS MONKEY ASSAULTAS ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/assaults\" -H 'Content-Type: application/json' -d '{ \"level\":1, \"latencyActive\":true, \"exceptionsActive\":false, \"killApplicationActive\":false, \"memoryActive\":false, \"cpuActive\":false }'"

echo "--- START CHAOS MONKEY RUNTIME ATTACK ---"
curl -X POST "$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/assaults/runtime/attack" -H 'Content-Type: application/json' || true

for number in {1..10}
do
echo "--- TEST REGULAR REQUEST ALL ROWS ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH\""
done

echo "----------------------------------------------------------"
echo "--- DISABLE APPLICATION CHAOS MONKEY CONFIGURATION ---"
echo "----------------------------------------------------------"


echo "--- DISABLE CHAOS MONKEY WATCHERS ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/watchers\" -H 'Content-Type: application/json' -d '{ \"controller\":false, \"restController\":false, \"service\":false, \"repository\":false, \"component\":false, \"restTemplate\":false, \"webClient\":false, \"actuatorHealth\":false}'"


echo "--- DISABLE CHAOS MONKEY ASSAULTAS ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/assaults\" -H 'Content-Type: application/json' -d '{ \"level\":1, \"latencyActive\":false, \"exceptionsActive\":false, \"killApplicationActive\":false, \"memoryActive\":false, \"cpuActive\":false }'"


echo "--- DISABLE CHAOS MONKEY IN APPLICATION ---"
assertCurl 200 "curl -X POST \"$PROTOCOL://$HOST:$PORT/actuator/chaosmonkey/disable\" -H 'Content-Type: application/json' "




