#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: test_script.sh ---"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

: ${HOST=localhost}
: ${PORT=3333}

#----------------------------------------------------------
#  HELP FUNCTIONS
#----------------------------------------------------------

function assertCurl() {

  local expectedHttpCode=$1
  local curlCmd="$2 -w \"%{http_code}\""
  local result=$(eval $curlCmd)
  local httpCode="${result:(-3)}"
  RESPONSE='' && (( ${#result} > 3 )) && RESPONSE="${result%???}"

  if [ "$httpCode" = "$expectedHttpCode" ]
  then
    if [ "$httpCode" = "200" ]
    then
      echo "Test OK (HTTP Code: $httpCode)"
    else
      echo "Test OK (HTTP Code: $httpCode, $RESPONSE)"
    fi
  else
    echo  "Test FAILED, EXPECTED HTTP Code: $expectedHttpCode, GOT: $httpCode, WILL ABORT!"
    echo  "- Failing command: $curlCmd"
    echo  "- Response Body: $RESPONSE"
    exit 1
  fi
}

function assertEqual() {

  local expected=$1
  local actual=$2

  if [ "$actual" = "$expected" ]
  then
    echo "Test OK (actual value: $actual)"
  else
    echo "Test FAILED, EXPECTED VALUE: $expected, ACTUAL VALUE: $actual, WILL ABORT"
    exit 1
  fi
}

function testUrl() {
  url=$@
  if $url -ks -f -o /dev/null
  then
    return 0
  else
    return 1
  fi;
}

function waitForService() {
  url=$@
  echo -n "Wait for: $url... "
  n=0
  until testUrl $url
  do
    n=$((n + 1))
    if [[ $n == 100 ]]
    then
      echo " Give up"
      exit 1
    else
      sleep 3
      echo -n ", retry #$n "
    fi
  done
  echo "DONE, continues..."
}

#----------------------------------------------------------
#  START END TO END TESTING
#----------------------------------------------------------

echo "----------------------------------------------------------"
echo "--- START TESTING ---"
echo "----------------------------------------------------------"

waitForService curl http://$HOST:$PORT/actuator/health

assertCurl 200 "curl http://$HOST:$PORT"

assertEqual "Hello From Microservice mss-template-service-a To Team: Marek,Sudipta" "$(echo $RESPONSE)"









 
