import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;
 
public class HttpSimulationJava extends Simulation 
{ 
	
  String host = System.getProperty("HOST", "localhost");
  
  String port = System.getProperty("PORT", "3333");	
	
  HttpProtocolBuilder  httpConf = http.baseUrl("http://"+host+":"+port).acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
  
  ScenarioBuilder scn = scenario("HttpSimulation")    
    .exec(http("Get All Requests")
    .get("/")
    .check(status().is(200)))
    ;

  {
    setUp
    (
      scn.injectOpen(rampUsers(100).during(5))
    ).protocols(httpConf);
  }
}
