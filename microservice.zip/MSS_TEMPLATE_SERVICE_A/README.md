## How to work with this project scaffold
In this readme you will find instructions specific to working with this Java Microservice scaffold based on Spring Boot. 

### File Structure
```
├── .gitignore - Common git ignore patterns.
├── chart/ - The Helm chart used to deploy the application to Kubernetes or OpenShift.
│   ├── values.yaml - The main K8s configuration file
├── Dockerfile - Used by Docker to build the app container image.
├── Jenkinsfile - Used by Jenkins to execute the build pipeline.
├── pom.xml - Maven Project definition file.
└── src/
    ├── main/
    │   ├── java/com/ccc/sec
    │   │   └── Application.java - Simple Spring Boot application.  
    │   ├── /resources/
    │       ├── application.yaml     - Used by Spring Boot to configure default application
    │       │                          configuration.  This is initialized with core
    │       │                          application capabilities such as metrics and health
    │       │                          via Spring Actuator.
    │       └── logback.xml      - Default logback logging configuration.
    └── test/java/com/ccc/sec
        ├── java/com/ccc/sec
            └── Application/test.java - Simple test class

```
