INSERT INTO users(username, first_name, last_name) VALUES('Marek', 'Marek', 'Dev');
INSERT INTO users(username, first_name, last_name) VALUES('Sudipta', 'Sudipta', 'Dev');