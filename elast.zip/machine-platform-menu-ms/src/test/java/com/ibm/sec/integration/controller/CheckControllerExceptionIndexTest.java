package com.ibm.sec.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.testcontainers.containers.wait.strategy.HttpWaitStrategy;
import org.testcontainers.elasticsearch.ElasticsearchContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

@Tag("Integration")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Slf4j
class CheckControllerExceptionIndexTest 
{
    @Container
    private static final ElasticsearchContainer MY_ELASTICSEARCH_CONTAINER = new ElasticsearchContainer("docker.elastic.co/elasticsearch/elasticsearch:7.17.3")
                                                                             .withEnv("ELASTIC_USERNAME", "elastic")
                                                                             .withEnv("ELASTIC_PASSWORD", "password")
                                                                             .withEnv("bootstrap.memory_lock", "true")
                                                                             .withEnv("discovery.type", "single-node")
                                                                             .withEnv("xpack.security.enabled", "true")
                                                                             .withExposedPorts(9200)
                                                                             .waitingFor(new HttpWaitStrategy().forPath("/")
                                                                            		                           .withBasicCredentials("elastic", "password")
                                                                            		                           .withStartupTimeout(Duration.ofMinutes(10)))
                                                                             ;
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.elasticsearch.uris", () ->  { return "http://localhost:" + MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort();});
        registry.add("spring.elasticsearch.password", () ->  "password");
        registry.add("spring.elasticsearch.username", () ->  "elastic");
        registry.add("app.elasticsearch.indexName", () -> ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate; 
		
	@BeforeAll
	public static void setUp()
	{
		
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@AfterEach
	public void stopTest()
	{

	}	
    
    @Test
    void check() 
    {

    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/check", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("\"statusCode\": 503"));
    	assertTrue(response.getBody().contains("\"message\": \"Down\""));
    	
    }    
    
    
    @Test
    void checkAll() 
    {

    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/check/all", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	System.out.println(response.getBody());
    	
    	assertTrue(response.getBody().contains("\"name\": \"ElasticSearch\""));
    	assertTrue(response.getBody().contains("\"statusCode\": 503"));
    	assertTrue(response.getBody().contains("\"message\": \"Error Missing Index: "+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+" \""));
    	
    }      
	
}
