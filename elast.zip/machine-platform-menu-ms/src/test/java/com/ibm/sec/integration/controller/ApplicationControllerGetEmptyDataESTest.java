package com.ibm.sec.integration.controller;

import static org.junit.Assert.assertEquals;
import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.testcontainers.containers.wait.strategy.HttpWaitStrategy;
import org.testcontainers.elasticsearch.ElasticsearchContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.web.client.RestTemplate;

@Tag("Integration")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Testcontainers
@Slf4j
class ApplicationControllerGetEmptyDataESTest 
{
    @Container
    private static final ElasticsearchContainer MY_ELASTICSEARCH_CONTAINER = new ElasticsearchContainer(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_VERSION_DOCKER)
                                                                             .withEnv("ELASTIC_USERNAME", "elastic")
                                                                             .withEnv("ELASTIC_PASSWORD", "password")
                                                                             .withEnv("bootstrap.memory_lock", "true")
                                                                             .withEnv("discovery.type", "single-node")
                                                                             .withEnv("xpack.security.enabled", "true")
                                                                             .withExposedPorts(9200)
                                                                             .waitingFor(new HttpWaitStrategy().forPath("/")
                                                                            		                           .withBasicCredentials("elastic", "password")
                                                                            		                           .withStartupTimeout(Duration.ofMinutes(10)))
                                                                             ;
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.elasticsearch.uris", () ->  { return "http://localhost:" + MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort();});
        registry.add("spring.elasticsearch.password", () ->  "password");
        registry.add("spring.elasticsearch.username", () ->  "elastic");
        registry.add("app.elasticsearch.indexName", () -> ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate; 
		
	@BeforeAll
	public static void setUp()
	{
		RestTemplateBuilder temp = new RestTemplateBuilder();

		RestTemplate restTemplateElastic = temp.basicAuthentication("elastic", "password").defaultHeader("Content-Type", "application/json").build();
		
       	// modify 
     	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	HttpEntity<String> entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS, headers);
    	
    	// Create ES index
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME, HttpMethod.PUT, entity, String.class); 
        
        // Add Data to Index
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000007, headers);
        
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000007", HttpMethod.PUT, entity, String.class);
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@AfterEach
	public void stopTest()
	{

	}	
    
	
    //*******************************************
    // DATA GET TESTING
    //*******************************************
	
    @Test
    void menuNotExistedId() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/000000000000100", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());    	
    }  
         
    @Test
    void menuNotExistedIdAll() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());    	
    }    
    
    @Test
    void menuNotExistedIdAllIncludeTotalCount() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());    	
    }  
      
}
