package com.ibm.sec.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.Duration;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.testcontainers.containers.wait.strategy.HttpWaitStrategy;
import org.testcontainers.elasticsearch.ElasticsearchContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.web.client.RestTemplate;

@Tag("Integration")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Slf4j
class ApplicationControllerGetDataESTest 
{
    @Container
    private static final ElasticsearchContainer MY_ELASTICSEARCH_CONTAINER = new ElasticsearchContainer(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_VERSION_DOCKER)
                                                                             .withEnv("ELASTIC_USERNAME", "elastic")
                                                                             .withEnv("ELASTIC_PASSWORD", "password")
                                                                             .withEnv("bootstrap.memory_lock", "true")
                                                                             .withEnv("discovery.type", "single-node")
                                                                             .withEnv("xpack.security.enabled", "true")
                                                                             .withExposedPorts(9200)
                                                                             .waitingFor(new HttpWaitStrategy().forPath("/")
                                                                            		                           .withBasicCredentials("elastic", "password")
                                                                            		                           .withStartupTimeout(Duration.ofMinutes(10)))
                                                                             ;
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.elasticsearch.uris", () ->  { return "http://localhost:" + MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort();});
        registry.add("spring.elasticsearch.password", () ->  "password");
        registry.add("spring.elasticsearch.username", () ->  "elastic");
        registry.add("app.elasticsearch.indexName", () -> ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate; 
		
	@BeforeAll
	public static void setUp()
	{
		RestTemplateBuilder temp = new RestTemplateBuilder();

		RestTemplate restTemplateElastic = temp.basicAuthentication("elastic", "password").defaultHeader("Content-Type", "application/json").build();
		
       	// modify 
     	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	HttpEntity<String> entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS, headers);
    	
    	// Create ES index
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME, HttpMethod.PUT, entity, String.class); 
        
        // Add Data to Index
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000001, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000001", HttpMethod.PUT, entity, String.class);
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000002, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000002", HttpMethod.PUT, entity, String.class);
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000003, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000003", HttpMethod.PUT, entity, String.class);   
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000004, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000004", HttpMethod.PUT, entity, String.class); 
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000005, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000005", HttpMethod.PUT, entity, String.class);  
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000006, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000006", HttpMethod.PUT, entity, String.class); 
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000007, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000007", HttpMethod.PUT, entity, String.class);   
        
        entity = new HttpEntity<String>(ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_DATA_000000000000008, headers);       
        restTemplateElastic.exchange("http://localhost:"+MY_ELASTICSEARCH_CONTAINER.getFirstMappedPort()+"/"+ElasticSearachIntegrationConfiguration.ELASTICSEARCH_INDEX_REMEDYMENUS_NAME+"/_doc/000000000000008", HttpMethod.PUT, entity, String.class);         
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@AfterEach
	public void stopTest()
	{

	}	
    
	//*******************************************	
    //*******************************************
    // Controller machine-platform-menu
    //*******************************************	
	//*******************************************	
	
    //*******************************************
    // DATA GET TESTING SINGLE  machine-platform-menu
    //*******************************************
	
    @Test
    void menuNotExistedIdOneRow() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/000000000000100", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());    	
    }  
    
    @Test
    void menuExistedIdNotInMenuPlatformNameScopeOneRow() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/000000000000007", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());    
    	
    	String id = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals("000000000000007", id); 
    	
    	
    	String status = JsonPath.read(response.getBody(), "$.status");
    	
    	assertEquals("Active", status); 
    	
    	
    	String shortDescription = JsonPath.read(response.getBody(), "$.shortDescription");
    	
    	assertEquals("shortDescription-7", shortDescription);    
    	
    	
    	String label = JsonPath.read(response.getBody(), "$.label");
    	
    	assertEquals("label-7", label);     
    	
    
    	String value = JsonPath.read(response.getBody(), "$.value");
    	
    	assertEquals("value-7", value);     	
    	
    	
    	String name = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("Something", name);    
    	
    	
    	String outerMenu1 = JsonPath.read(response.getBody(), "$.outerMenu1");
    	
    	assertEquals("Menu1-7", outerMenu1);
    	
    	
    	String outerMenu2 = JsonPath.read(response.getBody(), "$.outerMenu2");
    	
    	assertEquals("Menu2-7", outerMenu2);      	
    	
    }    
    
    @Test
    void menuExistedIdOneRow() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/000000000000001", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());  
    	   	    	
    	String id = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals("000000000000001", id); 
    	
    	
    	String status = JsonPath.read(response.getBody(), "$.status");
    	
    	assertEquals("Active", status); 
    	
    	
    	String shortDescription = JsonPath.read(response.getBody(), "$.shortDescription");
    	
    	assertEquals("shortDescription-1", shortDescription);    
    	
    	
    	String label = JsonPath.read(response.getBody(), "$.label");
    	
    	assertEquals("label-1", label);     
    	
    
    	String value = JsonPath.read(response.getBody(), "$.value");
    	
    	assertEquals("value-1", value);     	
    	
    	
    	String name = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("Machine Platform", name);    
    	
    	
    	String outerMenu1 = JsonPath.read(response.getBody(), "$.outerMenu1");
    	
    	assertEquals("Menu1-1", outerMenu1);
    	
    	
    	String outerMenu2 = JsonPath.read(response.getBody(), "$.outerMenu2");
    	
    	assertEquals("Menu2-1", outerMenu2);     	
    	
    }     
    
    
    //*******************************************
    // DATA GET TESTING MULTIPLE
    //*******************************************
    
    @Test
    void menuCheckAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());

    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    }    
    
    @Test
    void menuCheckIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());  
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(6, totalCount); 
    	
    } 
    
    //*******************************************
    // PAGINATION TESTING
    //*******************************************    
    
    @Test
    void menuCheckPaginationWithPage0AllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?page=0&size=3", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    }  
    
    
    @Test
    void menuCheckPaginationWithPage0IncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&page=0&size=3", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());

    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(3, totalCount);     	
    }    
    
    @Test
    void menuCheckPaginationWithPage1AllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?page=1&size=3", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());    	
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    }  
    
    
    @Test
    void menuCheckPaginationWithPage1IncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&page=1&size=3", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(3, totalCount);     	
    }     
     
    //*******************************************
    // FILTER TESTING
    //******************************************* 
    
    @Test
    void menuCheckWithFilterMultiIdsAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?ids=000000000000001,000000000000002,000000000000003,000000000000007,000000000000008", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    	    	
    }     
    
    
    @Test
    void menuCheckWithFilterMultiIdsIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&ids=000000000000001,000000000000002,000000000000003,000000000000007,000000000000008", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(3, totalCount);      	
    	    	
    }    
    
    
    @Test
    void menuCheckWithFilterWrongIdsIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&ids=000000000000007,000000000000008,000000000000009", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());    	    	    	
    }     
    
    
    @Test
    void menuCheckWithFilterStatusesAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?statuses=Active", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    	    	
    }  
    
    
    @Test
    void menuCheckWithFilterStatusesIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&statuses=Active", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size()); 
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(3, totalCount);    	
    	    	
    }     
    
      
    @Test
    void menuCheckWithFilterMultiStatusesAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?statuses=Active,Inactive", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	    	
    }  
    
    
    @Test
    void menuCheckWithFilterMultiStatusesIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&statuses=Active,Inactive", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(6, totalCount);    	
    	    	
    }    
    
    
    @Test
    void menuCheckWithFilterWrongStatusesAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?statuses=Wrong1,Wrong2", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    	    	
    }  
    
    
    @Test
    void menuCheckWithFilterWrongStatusesIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&statuses=Wrong1,Wrong2", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());    	    	
    }     
    
    
    @Test
    void menuCheckWithFilterMultiIdsMultiStatusesAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?ids=000000000000001,000000000000002,000000000000003,000000000000004&statuses=Active,Whatever", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(2, allItems.size()); 
    	    	
    }     
    
    
    @Test
    void menuCheckWithFilterMultiIdsMultiStatusesIncludeTotalCountAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?includeTotalCount=true&ids=000000000000001,000000000000002,000000000000003,000000000000004&statuses=Active,Whatever", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(2, allItems.size()); 
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(2, totalCount);      	
    	    	
    }      
    
    //*******************************************
    // SORTING TESTING
    //*******************************************
    @Test
    void menuCheckSortByIdAscAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?sort=id:ASC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	
    	String id000000000000001 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals("000000000000001", id000000000000001);          	
    	    	
    }     
    
    @Test
    void menuCheckSortByIdDescAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?sort=id:DESC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	
    	String id000000000000006 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals("000000000000006", id000000000000006);          	
    	    	
    }    
    
    
    @Test
    void menuCheckSortByStatusAscAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?sort=status:ASC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	
    	String id000000000000001 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals("000000000000001", id000000000000001);          	
    	    	
    }     
    
    @Test
    void menuCheckSortByStatusDescAllRows() 
    {            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu?sort=status:DESC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size()); 
    	
    	String id000000000000002 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals("000000000000002", id000000000000002);          	
    	    	
    }    
    
	//*******************************************	
    //*******************************************
    // Controller check
    //*******************************************	
	//*******************************************    
    @Test
    void check() 
    {
            	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/check", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("\"statusCode\": 200"));
    	assertTrue(response.getBody().contains("\"message\": \"Up\""));
    	
    }  
    
    
    @Test
    void checkAll() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/machine-platform-menu/check/all", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("\"name\": \"ElasticSearch\""));
    	assertTrue(response.getBody().contains("\"statusCode\": 200"));
    	assertTrue(response.getBody().contains("\"message\": \"Connected\""));
    	    	
    }     
    
    
	//*******************************************	
    //*******************************************
    // Controller swagger
    //*******************************************	
	//*******************************************       
    
    @Test
    void swaggerV2() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/swagger", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("swagger:"));
    	
    	
    	ResponseEntity<String> response1 = restTemplate.getForEntity("http://localhost:"+port+"/swagger/", String.class);
		 
    	assertEquals(HttpStatus.OK, response1.getStatusCode());
    	assertTrue(response1.getBody().contains("swagger:"));
    	
    	
    	ResponseEntity<String> response2 = restTemplate.getForEntity("http://localhost:"+port+"/swagger/v2", String.class);
		 
    	assertEquals(HttpStatus.OK, response2.getStatusCode());
    	assertTrue(response2.getBody().contains("swagger:"));
    	
    }  
    
    
    @Test
    void swaggerV3() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/swagger/v3", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("openapi:"));
    	
    }        
	    
    
	//*******************************************	
    //*******************************************
    // Controller actuator
    //*******************************************	
	//*******************************************   
    
    @Test
    void actuatorHealth() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/actuator/health", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    }     
    
    @Test
    void actuatorHealthLiveness() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/actuator/health/liveness", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    }     
    
    @Test
    void actuatorHealthReadiness() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/actuator/health/readiness", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    }      
     
}
