package com.ibm.sec.filter;

import com.ibm.sec.model.SessionDetail;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.annotation.Resource;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Add session id for every request - allow trace requests coming to microservice
 */
@Component
@Order(1)
public class PreFilter extends OncePerRequestFilter {
		
    @Resource(name = "requestScopedBean")
    private SessionDetail requestScopedBean;	
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		requestScopedBean.setThreadUuid(request.getRequestedSessionId());
		filterChain.doFilter(request, response);
	}
}
