package com.ibm.sec.model;

import lombok.Builder;
import lombok.Getter;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@Getter
@Builder
public class CustomResponse
{
	@JsonProperty("items")
    List<RemedyMenu> remedyMenuList;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer totalCount;
}
