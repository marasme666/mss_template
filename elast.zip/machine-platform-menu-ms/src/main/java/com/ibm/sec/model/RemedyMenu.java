package com.ibm.sec.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.NoArgsConstructor;
import lombok.AccessLevel;
import lombok.Getter;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Getter
@NoArgsConstructor(access=AccessLevel.PUBLIC, force=true)
@JsonIgnoreProperties(
        ignoreUnknown = true
)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Document(indexName = "#{@ApplicationConfig.ElasticSearch.indexName}", createIndex=false)
public class RemedyMenu {

    @Id
    private String id;

    private String status;

    private String shortDescription;

    private String label;

    private String value;

    private String name;

    private String outerMenu1;

    private String outerMenu2;

}
