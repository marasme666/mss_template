package com.ibm.sec.repository;

import com.ibm.sec.model.RemedyMenu;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface RemedyMenuRepo extends ReactiveCrudRepository<RemedyMenu, String> {
	
}
