package com.ibm.sec.controller;


import com.ibm.sec.model.CustomResponse;
import com.ibm.sec.model.RemedyMenu;
import com.ibm.sec.model.SessionDetail;
import com.ibm.sec.service.ApplicationService;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.*;
import java.util.stream.Collectors;

import javax.annotation.Resource;

@RestController
@RequestMapping("/machine-platform-menu")
@Slf4j
public class ApplicationController {
	
    @Autowired
    private ApplicationService appService;

    @Resource(name = "requestScopedBean")
    private SessionDetail requestScopedBean;    
    
    @Value("${app.defaultPage}")
    private String defaultPage;

    @Value("${app.pageSize}")
    private String pageSize;

    @GetMapping("/{id}")
    public Mono<ResponseEntity<RemedyMenu>> getMenuById(@PathVariable String id)
    {
        log.info(String.format(" Received GET request to fetch RemedyMenu for ID: %s with Session Id %s", id.replaceAll("[\r\n]",""), requestScopedBean.getThreadUuid()));
        
        return appService.getById(id)
        		.map( x -> new ResponseEntity<>(x, HttpStatus.OK))
        		.defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
        		;
        	
    }

    @GetMapping
    public Mono<ResponseEntity<CustomResponse>> getAllMenus(@RequestParam Map<String, String> menuFilter)
    {
        log.info(String.format("Received GET request to Fetch RemedyMenu[s] for Params: %s with Session Id %s", menuFilter.entrySet().stream().map(e -> e.getKey().replaceAll("[\r\n]","") + ":" + e.getValue().replaceAll("[\r\n]","")).collect(Collectors.joining("|")), requestScopedBean.getThreadUuid()));

        Sort sort;
        if(menuFilter.containsKey("sort"))
        {
            List<String>values  = Arrays.asList(menuFilter.get("sort").split("\\s*:\\s*"));
            sort = Sort.by(Sort.Direction.valueOf(values.get(1)), values.get(0));
            menuFilter.remove("sort");
        }
        else 
        {
            sort = Sort.by(Sort.Direction.DESC, "id");
        }
        
        Pageable pageable = PageRequest.of(Integer.valueOf(menuFilter.getOrDefault("page", defaultPage)), Integer.valueOf(menuFilter.getOrDefault("size", pageSize)), sort);

        menuFilter.remove("page");
        menuFilter.remove("size");
        
        return appService.getAllMenuByFilter(menuFilter, pageable)
               .map( x -> 
                    {
		            	   if(x.getRemedyMenuList().size() == 0)
		            	   {
		            		  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		            	   }
		            	   else
		            	   {
		            		  return new ResponseEntity<>(x, HttpStatus.OK);
		            	   }
               		})
               ;
    }
}
