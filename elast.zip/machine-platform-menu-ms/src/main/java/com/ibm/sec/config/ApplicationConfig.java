package com.ibm.sec.config;

import lombok.Getter;
import lombok.Setter;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;


@Configuration("ApplicationConfig")
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
@Validated
public class ApplicationConfig {
    private ElasticSearch elasticSearch;
    
    @Getter
    @Setter
    @Valid
    public static class ElasticSearch 
    {    
        @NotBlank
        private String indexName;
        
        @NotBlank
        private String menuName;        
    }
}