package com.ibm.sec.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;

/**
 *REST API microservice swagger controller - support v2 and v3 openapi
 */
@Slf4j
@RestController
@RequestMapping("/swagger")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SwaggerController {
	
    private final ResourceLoader resourceLoader;
    
    @Value("${swagger.v2.file.location}")
    private String swaggerV2FileLocation;
    
    @Value("${swagger.v3.file.location}")
    private String swaggerV3FileLocation;    

    @GetMapping({"","/","v2"})
    public Mono<ResponseEntity<String>> swaggerVersion2()
    {
    	log.info("Get Swagger v2 file");
    	
        Resource resource = resourceLoader.getResource(swaggerV2FileLocation);
        
        return Mono.fromCallable(() -> { return StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);})
          	   .map(x -> (new ResponseEntity<>(x, HttpStatus.OK)))
          	   .onErrorReturn(new ResponseEntity<>(HttpStatus.NOT_FOUND))
          	   .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
          	   ;
    }
    
    @GetMapping({"v3"})
    public Mono<ResponseEntity<String>> swaggerVersion3()
    {
    	
    	log.info("Get Swagger v3 file");
    	
        Resource resource = resourceLoader.getResource(swaggerV3FileLocation);

        return Mono.fromCallable(() -> { return StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);})
         	   .map(x -> (new ResponseEntity<>(x, HttpStatus.OK)))
         	   .onErrorReturn(new ResponseEntity<>(HttpStatus.NOT_FOUND))
         	   .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND))
         	   ;
    }    
    
}