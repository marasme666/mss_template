package com.ibm.sec.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.io.IOException;

import org.elasticsearch.client.indices.GetIndexRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.elasticsearch.ElasticsearchReactiveHealthIndicator;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.data.elasticsearch.client.reactive.ReactiveElasticsearchClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.sec.config.ApplicationConfig;


/**
 * REST API microservice status controller
 */
@Slf4j
@RestController
@RequestMapping("/machine-platform-menu/check")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CheckController 
{	
	private final HealthEndpoint healthEndpoint;
		
	private final ElasticsearchReactiveHealthIndicator elasticsearchRestHealthIndicator;
	
	private final ReactiveElasticsearchClient reactiveElasticsearchClient;
	
	private final ApplicationConfig config;
	
    /**
     * @return status
     */
    @GetMapping()
    public Mono<ResponseEntity<String>> check() throws IOException 
    {
    	log.info("Get Check Status");
    	    	
    	return Mono.fromCallable(() -> { return healthEndpoint.health().getStatus();})
    			.filter(x -> x.equals(org.springframework.boot.actuate.health.Status.UP))
    			.flatMap( x -> reactiveElasticsearchClient.indices().existsIndex(new GetIndexRequest(config.getElasticSearch().getIndexName())))
    			.filter(x -> x.equals(true))
    			.map( x -> new ResponseEntity<>("{ \"statusCode\": 200,  \"message\": \"Up\" }", HttpStatus.OK))
    			.onErrorReturn(new ResponseEntity<>("{ \"statusCode\": 503,  \"message\": \"Down\" }", HttpStatus.OK))
    			.defaultIfEmpty(new ResponseEntity<>("{ \"statusCode\": 503,  \"message\": \"Down\" }", HttpStatus.OK))
    			;

    }
    
    /**
     * @return detail status
     */
    @GetMapping({"/all"})
    public Mono<ResponseEntity<String>> checkAll() throws IOException 
    {    	
    	log.info("Get Check All Status");
    	
    	return elasticsearchRestHealthIndicator.getHealth(false)
    			.filter(x -> x.getStatus().equals(org.springframework.boot.actuate.health.Status.UP))
    			.flatMap( x -> reactiveElasticsearchClient.indices().existsIndex(new GetIndexRequest(config.getElasticSearch().getIndexName())))
    			.map(x -> {     					
					if(x.equals(true))
					{
						return new ResponseEntity<>("{ \"statusItems\": [ { \"name\": \"ElasticSearch\", \"statusCode\": 200, \"message\": \"Connected\" } ] }", HttpStatus.OK);
					}
					else
					{
						return new ResponseEntity<>("{ \"statusItems\": [ { \"name\": \"ElasticSearch\", \"statusCode\": 503, \"message\": \"Error Missing Index: "+config.getElasticSearch().getIndexName()+" \" } ] }", HttpStatus.OK);
					}
				})
    			.onErrorReturn(new ResponseEntity<>("{ \"statusItems\": [ { \"name\": \"ElasticSearch\", \"statusCode\": 503, \"message\": \"Error\" } ] }", HttpStatus.OK))
    			.defaultIfEmpty(new ResponseEntity<>("{ \"statusItems\": [ { \"name\": \"ElasticSearch\", \"statusCode\": 503, \"message\": \"Error\" } ] }", HttpStatus.OK))
    			;
    		
    }       
    
}
