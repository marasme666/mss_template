package com.ibm.sec.service;


import com.ibm.sec.config.ApplicationConfig;
import com.ibm.sec.model.CustomResponse;
import com.ibm.sec.model.RemedyMenu;
import com.ibm.sec.model.SessionDetail;
import com.ibm.sec.repository.RemedyMenuRepo;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.core.query.StringQuery;
import org.springframework.data.elasticsearch.core.ReactiveElasticsearchOperations;
import org.springframework.data.elasticsearch.core.query.Query;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import java.util.*;

@Slf4j
@Service
public class ApplicationService {
	
	private static final String INCLUDE_TOTAL_COUNT = "includeTotalCount";  
	
	private static final String IDS = "ids";  
	
	private static final String STATUSES = "statuses";
	
    @Autowired
    private RemedyMenuRepo remedyMenuRepo;
    
    @Autowired
    private ReactiveElasticsearchOperations reactiveElasticsearchOperations;   
    
    @Autowired
    private ApplicationConfig config;   

    @Resource(name = "requestScopedBean")
    private SessionDetail requestScopedBean;

    public Mono<RemedyMenu> getById(@NotNull String id)
    {
    	log.info(String.format("getById - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
    	
        return remedyMenuRepo.findById(id)
                .doOnSuccess(e -> log.info(String.format("Successfull load data from ElasticSearch for id: %s", id)))
                .doOnError(e -> log.error(String.format("Error loading data from ElasticSearch for id: %s", id)));
    }

    public Mono<CustomResponse> getAllMenuByFilter(Map<String, String> menuFilter, Pageable pageable) 
    {
    	log.info(String.format("getAllMenuByFilter - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
    	
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        boolQueryBuilder.must(QueryBuilders.matchPhraseQuery("name", config.getElasticSearch().getMenuName()));
        Boolean[] customResponse = {false}; // need it for rective call support
        if(menuFilter.containsKey(INCLUDE_TOTAL_COUNT) && menuFilter.get(INCLUDE_TOTAL_COUNT).equals("true"))
        {
        	customResponse[0] = true;
        }
        		
        menuFilter.remove(INCLUDE_TOTAL_COUNT);
        
        menuFilter.forEach((k,v)->
        {
            if(k.equals(IDS))
            {
            	BoolQueryBuilder boolQueryBuilderId = QueryBuilders.boolQuery();
                List<String>values = Arrays.asList(v.split("\\s*,\\s*"));
                values.forEach(s->boolQueryBuilderId.should(QueryBuilders.matchPhraseQuery("id",s)));
            	
                boolQueryBuilder.must(boolQueryBuilderId);
            }
            else if(k.equals(STATUSES)) 
            {
            	BoolQueryBuilder boolQueryBuilderStatus = QueryBuilders.boolQuery();
                List<String> values = Arrays.asList(v.split("\\s*,\\s*"));
                values.forEach(s -> boolQueryBuilderStatus.should(QueryBuilders.matchPhraseQuery("status", s)));
                
                boolQueryBuilder.must(boolQueryBuilderStatus);
            }
            else 
            {
                boolQueryBuilder.must(QueryBuilders.matchPhraseQuery(k, v));
            }
        });
        
        sourceBuilder.query(boolQueryBuilder);
        
        Query queryString = new StringQuery(sourceBuilder.query().toString());
                
        queryString.setPageable(pageable);
                       
    	return  reactiveElasticsearchOperations.search(queryString, RemedyMenu.class)
    			.map(x -> x.getContent())
    			.collectList()
    			.map(x -> {
    				if(customResponse[0])
    				{
    					return CustomResponse.builder().remedyMenuList(x).totalCount(x.size()).build();
    				}
    				else
    				{
    					return CustomResponse.builder().remedyMenuList(x).totalCount(null).build();
    				}
    				
    			});
        
    }


}
