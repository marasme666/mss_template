package com.ibm.sec.config;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.http.HttpHost;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.reactive.ReactiveElasticsearchClient;
import org.springframework.data.elasticsearch.client.reactive.ReactiveRestClients;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class ElasticsearchConfig 
{	
    @Value("${spring.elasticsearch.uris}")
    private String[] uris;
    
    @Value("${spring.elasticsearch.username}")
    private String username;    
    
    @Value("${spring.elasticsearch.password}")
    private String password;      
		
    @Bean
    public ReactiveElasticsearchClient reactiveElasticsearchClient() 
    {
    	
    	ClientConfiguration clientConfiguration =  null;
    	
    	String hostPort =  Arrays.stream(uris).map(x -> HttpHost.create(x)).map(x -> x.getHostName()+":"+x.getPort()).collect(Collectors.joining(","));
    	    	
    	if(uris[0].toUpperCase().startsWith("HTTPS://"))
    	{
    	 
    	  log.info("Use https to connect Elasticsearch");	
    	  	
    	  clientConfiguration = ClientConfiguration.builder()
    	             .connectedTo(hostPort.split(","))
    	             .usingSsl()
    	             .withBasicAuth(username, password)
    	             .build();
    	}
    	else
    	{
    	   log.info("Use http to connect Elasticsearch");		
    		
 	       clientConfiguration = ClientConfiguration.builder()
 	    		  .connectedTo(hostPort.split(","))
	                .withBasicAuth(username, password)
	                .build();
    	}

        return ReactiveRestClients.create(clientConfiguration);
    }
	
}
