#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_test_all.sh ---"
echo "-------------------------------"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#MICROSERVICE NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
MICROSERVICE_NAME=${2:-machine-platform-menu-ms}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${3:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
GL_HELM_RELEASE_INFRA_NAME=infra-gl

# MICROSERVICE INFRA RELEASE NAME - PLEASE NOT CHANGE IT
MS_HELM_RELEASE_INFRA_NAME=infra-ms-${MICROSERVICE_NAME}

#----------------------------------------------------------
#  LOCAL VARIABLES
#----------------------------------------------------------
# ELASTICSEARCH INDEX NAME
ELASTICSEARCH_INDEX_NAME=remedymenus

# ELASTICSEARCH USERNAME
ELASTICSEARCH_USERNAME=elastic

# ELASTICSEARCH PASSWORD
ELASTICSEARCH_PASSWORD=password


#----------------------------------------------------------
# RUN TEST ON MICROSERVICE POD
#----------------------------------------------------------

cd testing

docker build -t localhost/test-client-${MICROSERVICE_NAME}:latest . 

kind load docker-image localhost/test-client-${MICROSERVICE_NAME}:latest  --name ${CLUSTER_NAME}-cluster


echo "--- RUN TEST ON POD CLIENT ---"

echo "Restarting alpine-client..."

if kubectl --context=$KIND_CLUSTER_NAME  get pod test-client-${MICROSERVICE_NAME} > /dev/null ; then
    kubectl --context=$KIND_CLUSTER_NAME  delete pod test-client-${MICROSERVICE_NAME} --grace-period=1
fi

kubectl --context=$KIND_CLUSTER_NAME  run test-client-${MICROSERVICE_NAME} --restart=Never --image=localhost/test-client-${MICROSERVICE_NAME}:latest --image-pull-policy=IfNotPresent --command -- sleep 6000000

echo "--- WAIT FOR K8S CLUSTER TO BE READY ---"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=ready pod --all --timeout=${DEFAULT_TIMEOUT}

echo "******************************"
echo "******************************"
echo "--- SET UP TEST ELASTICSEARCH INDEX FOR FUNCTIONAL TEST---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X DELETE -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME} -H 'Content-Type:application/json' -d '{\"aliases\":{},\"mappings\":{\"dynamic_templates\":[{\"TextType\":{\"match\":\"*Text\",\"mapping\":{\"index\":true,\"type\":\"text\"}}},{\"DateType\":{\"match\":\"*Date\",\"mapping\":{\"format\":\"YYYY-MM-dd HH:mm:ss ZZ||yyyy-MM-dd||EEE MMM dd HH:mm:ss zzz yyyy\",\"type\":\"date\"}}},{\"IPStringType\":{\"match\":\"*IpAddr\",\"match_mapping_type\":\"string\",\"mapping\":{\"analyzer\":\"custom_analyzer_uppercaseexact\",\"type\":\"keyword\"}}},{\"UpperCaseExactType\":{\"match\":\"*\",\"match_mapping_type\":\"string\",\"mapping\":{\"analyzer\":\"custom_analyzer_uppercaseexact\",\"type\":\"keyword\"}}}],\"properties\":{\"id\":{\"type\":\"keyword\"},\"label\":{\"type\":\"keyword\"},\"mss_sort_portalViewable\":{\"type\":\"long\"},\"mss_sort_status\":{\"type\":\"long\"},\"name\":{\"type\":\"keyword\"},\"outerMenu1\":{\"type\":\"keyword\"},\"outerMenu2\":{\"type\":\"keyword\"},\"portalViewable\":{\"type\":\"keyword\"},\"remedyAppsTime\":{\"type\":\"keyword\"},\"shortDescription\":{\"type\":\"keyword\"},\"status\":{\"type\":\"keyword\"},\"value\":{\"type\":\"keyword\"}}},\"settings\":{\"index\":{\"routing\":{\"allocation\":{\"include\":{\"_tier_preference\":\"data_content\"}}},\"number_of_shards\":\"1\",\"analysis\":{\"analyzer\":{\"custom_analyzer_email\":{\"tokenizer\":\"uax_url_email\"},\"custom_analyzer_ipv6\":{\"filter\":[\"uppercase\"],\"char_filter\":[\"omit_colon_filter\"],\"tokenizer\":\"standard\"},\"custom_analyzer_uppercaseexact\":{\"filter\":[\"uppercase\"],\"tokenizer\":\"keyword\"}},\"char_filter\":{\"omit_colon_filter\":{\"type\":\"mapping\",\"mappings\":[\":=>\"]}}},\"number_of_replicas\":\"1\"}}}'"

echo "******************************"
echo "******************************"
echo "--- PREPARE ELASTICSEARCH DATA FOR FUNCTIONAL TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000001 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000001\",  \"label\" : \"label-1\", \"mss_sort_portalViewable\" : 1, \"mss_sort_status\" : 1, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-1\", \"outerMenu2\" : \"Menu2-1\", \"portalViewable\" : \"portalViewable-1\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-1\", \"status\":\"Active\", \"value\" : \"value-1\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000002 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000002\",  \"label\" : \"label-2\", \"mss_sort_portalViewable\" : 2, \"mss_sort_status\" : 2, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-2\", \"outerMenu2\" : \"Menu2-2\", \"portalViewable\" : \"portalViewable-2\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-2\", \"status\":\"Inactive\", \"value\" : \"value-2\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000003 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000003\",  \"label\" : \"label-3\", \"mss_sort_portalViewable\" : 3, \"mss_sort_status\" : 3, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-3\", \"outerMenu2\" : \"Menu2-3\", \"portalViewable\" : \"portalViewable-3\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-3\", \"status\":\"Active\", \"value\" : \"value-3\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000004 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000004\",  \"label\" : \"label-4\", \"mss_sort_portalViewable\" : 4, \"mss_sort_status\" : 4, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-4\", \"outerMenu2\" : \"Menu2-4\", \"portalViewable\" : \"portalViewable-4\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-4\", \"status\":\"Inactive\", \"value\" : \"value-4\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000005 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000005\",  \"label\" : \"label-6\", \"mss_sort_portalViewable\" : 5, \"mss_sort_status\" : 5, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-5\", \"outerMenu2\" : \"Menu2-5\", \"portalViewable\" : \"portalViewable-5\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-5\", \"status\":\"Active\", \"value\" : \"value-5\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000006 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000006\",  \"label\" : \"label-6\", \"mss_sort_portalViewable\" : 6, \"mss_sort_status\" : 6, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-6\", \"outerMenu2\" : \"Menu2-6\", \"portalViewable\" : \"portalViewable-6\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-6\", \"status\":\"Inactive\", \"value\" : \"value-6\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000007 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000007\",  \"label\" : \"label-7\", \"mss_sort_portalViewable\" : 7, \"mss_sort_status\" : 7, \"name\" : \"Something\", \"outerMenu1\" : \"Menu1-7\", \"outerMenu2\" : \"Menu2-7\", \"portalViewable\" : \"portalViewable-7\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-7\", \"status\":\"Active\", \"value\" : \"value-7\"}'"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/000000000000008 -H 'Content-Type:application/json' -d '{\"id\" : \"000000000000008\",  \"label\" : \"label-8\", \"mss_sort_portalViewable\" : 8, \"mss_sort_status\" : 8, \"name\" : \"Something\", \"outerMenu1\" : \"Menu1-8\", \"outerMenu2\" : \"Menu2-8\", \"portalViewable\" : \"portalViewable-8\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-8\", \"status\":\"Inactive\", \"value\" : \"value-8\"}'"

sleep 1

echo "******************************"
echo "******************************"
echo "--- START FUNCTIONAL TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./functional/functional_test_script.sh test-client-${MICROSERVICE_NAME}:/tmp/functional_test_script.sh

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c "HOST=machine-platform-menu-ms PORT=3333 /tmp/functional_test_script.sh" 


echo "******************************"
echo "******************************"
echo "--- SET UP TEST ELASTICSEARCH INDEX FOR PERFORMANCE TEST---"
echo "******************************"
echo "******************************"
kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X DELETE -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}"

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME} -H 'Content-Type:application/json' -d '{\"aliases\":{},\"mappings\":{\"dynamic_templates\":[{\"TextType\":{\"match\":\"*Text\",\"mapping\":{\"index\":true,\"type\":\"text\"}}},{\"DateType\":{\"match\":\"*Date\",\"mapping\":{\"format\":\"YYYY-MM-dd HH:mm:ss ZZ||yyyy-MM-dd||EEE MMM dd HH:mm:ss zzz yyyy\",\"type\":\"date\"}}},{\"IPStringType\":{\"match\":\"*IpAddr\",\"match_mapping_type\":\"string\",\"mapping\":{\"analyzer\":\"custom_analyzer_uppercaseexact\",\"type\":\"keyword\"}}},{\"UpperCaseExactType\":{\"match\":\"*\",\"match_mapping_type\":\"string\",\"mapping\":{\"analyzer\":\"custom_analyzer_uppercaseexact\",\"type\":\"keyword\"}}}],\"properties\":{\"id\":{\"type\":\"keyword\"},\"label\":{\"type\":\"keyword\"},\"mss_sort_portalViewable\":{\"type\":\"long\"},\"mss_sort_status\":{\"type\":\"long\"},\"name\":{\"type\":\"keyword\"},\"outerMenu1\":{\"type\":\"keyword\"},\"outerMenu2\":{\"type\":\"keyword\"},\"portalViewable\":{\"type\":\"keyword\"},\"remedyAppsTime\":{\"type\":\"keyword\"},\"shortDescription\":{\"type\":\"keyword\"},\"status\":{\"type\":\"keyword\"},\"value\":{\"type\":\"keyword\"}}},\"settings\":{\"index\":{\"routing\":{\"allocation\":{\"include\":{\"_tier_preference\":\"data_content\"}}},\"number_of_shards\":\"1\",\"analysis\":{\"analyzer\":{\"custom_analyzer_email\":{\"tokenizer\":\"uax_url_email\"},\"custom_analyzer_ipv6\":{\"filter\":[\"uppercase\"],\"char_filter\":[\"omit_colon_filter\"],\"tokenizer\":\"standard\"},\"custom_analyzer_uppercaseexact\":{\"filter\":[\"uppercase\"],\"tokenizer\":\"keyword\"}},\"char_filter\":{\"omit_colon_filter\":{\"type\":\"mapping\",\"mappings\":[\":=>\"]}}},\"number_of_replicas\":\"1\"}}}'"

echo "******************************"
echo "******************************"
echo "--- PREPARE ELASTICSEARCH DATA FOR PERFORMANCE TEST ---"
echo "******************************"
echo "******************************"
for number in {1..100}
do
echo " "
kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " curl -X PUT -u ${ELASTICSEARCH_USERNAME}:${ELASTICSEARCH_PASSWORD} http://elasticsearch-master:9200/${ELASTICSEARCH_INDEX_NAME}/_doc/${number} -H 'Content-Type:application/json' -d '{\"id\" : \"${number}\",  \"label\" : \"label-${number}\", \"mss_sort_portalViewable\" : ${number}, \"mss_sort_status\" : ${number}, \"name\" : \"Machine Platform\", \"outerMenu1\" : \"Menu1-${number}\", \"outerMenu2\" : \"Menu2-${number}\", \"portalViewable\" : \"portalViewable-${number}\", \"remedyAppsTime\" : \"1653032238839\", \"shortDescription\" : \"shortDescription-${number}\", \"status\":\"Active\", \"value\" : \"value-${number}\"}'"
done

echo "******************************"
echo "******************************"
echo "--- START PERFORMANCE TEST ---"
echo "******************************"
echo "******************************"
sleep 1

kubectl --context=$KIND_CLUSTER_NAME cp ./performance/gatling test-client-${MICROSERVICE_NAME}:/opt/gatling-charts-highcharts-bundle/user-files/simulations/

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " JAVA_OPTS=\"-DHOST=machine-platform-menu-ms -DPORT=3333 \" /opt/gatling-charts-highcharts-bundle/bin/gatling.sh -s HttpSimulationJava -nr" 

cd ..

