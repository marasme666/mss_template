#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: test_script.sh ---"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

: ${PROTOCOL=http}
: ${HOST=localhost}
: ${PORT=3333}
: ${URLPATH=machine-platform-menu}

#----------------------------------------------------------
#  HELP FUNCTIONS
#----------------------------------------------------------

function assertCurl() {

  local expectedHttpCode=$1
  local curlCmd="$2 -w \"%{http_code}\""
  local result=$(eval $curlCmd)
  local httpCode="${result:(-3)}"
  RESPONSE='' && (( ${#result} > 3 )) && RESPONSE="${result%???}"

  if [ "$httpCode" = "$expectedHttpCode" ]
  then
    if [ "$httpCode" = "200" ]
    then
      echo "Test OK (HTTP Code: $httpCode)"
    else
      echo "Test OK (HTTP Code: $httpCode, $RESPONSE)"
    fi
  else
    echo  "Test FAILED, EXPECTED HTTP Code: $expectedHttpCode, GOT: $httpCode, WILL ABORT!"
    echo  "- Failing command: $curlCmd"
    echo  "- Response Body: $RESPONSE"
    exit 1
  fi
}

function assertEqual() {

  local expected=$1
  local actual=$2

  if [ "$actual" = "$expected" ]
  then
    echo "Test OK (actual value: $actual)"
  else
    echo "Test FAILED, EXPECTED VALUE: $expected, ACTUAL VALUE: $actual, WILL ABORT"
    exit 1
  fi
}

function testUrl() {
  url=$@
  if $url -ks -f -o /dev/null
  then
    return 0
  else
    return 1
  fi;
}

function waitForService() {
  url=$@
  echo -n "Wait for: $url... "
  n=0
  until testUrl $url
  do
    n=$((n + 1))
    if [[ $n == 100 ]]
    then
      echo " Give up"
      exit 1
    else
      sleep 3
      echo -n ", retry #$n "
    fi
  done
  echo "DONE, continues..."
}

#----------------------------------------------------------
#  START END TO END TESTING
#----------------------------------------------------------

echo "----------------------------------------------------------"
echo "--- START TESTING ---"
echo "----------------------------------------------------------"

# Wait for microservice to be ready
waitForService curl $PROTOCOL://$HOST:$PORT/actuator/health


#----------------------------------------------------------
#  GET TESTING 
#----------------------------------------------------------

echo "----------------------------------------------------------"
echo "--- GET ACTUATOR KUBERNETES TESTING ---"
echo "----------------------------------------------------------"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/actuator/health/liveness\""

assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/actuator/health/readiness\""

echo "----------------------------------------------------------"
echo "--- GET CHECK TESTING ---"
echo "----------------------------------------------------------"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/check\""
assertEqual 200 $(echo $RESPONSE | jq ".statusCode")
assertEqual \"Up\" $(echo $RESPONSE | jq ".message")

assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/check/all\""
assertEqual 200 $(echo $RESPONSE | jq ".statusItems[0].statusCode")
assertEqual \"Connected\" $(echo $RESPONSE | jq ".statusItems[0].message")
assertEqual \"ElasticSearch\" $(echo $RESPONSE | jq ".statusItems[0].name")

echo "----------------------------------------------------------"
echo "--- GET BUSINESS TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST REGULAR REQUEST ALL ROWS ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")

echo "--- TEST REGULAR REQUEST ALL ROWS: INCLUDE-TOTAL-COUNT ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?includeTotalCount=true\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")
assertEqual 6 $(echo $RESPONSE | jq ".totalCount")

echo "--- TEST PAGINATION ALL ROWS ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?page=0&size=3\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")

echo "--- TEST PAGINATION ALL ROWS: INCLUDE-TOTAL-COUNT ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?includeTotalCount=true&page=0&size=3\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")
assertEqual 3 $(echo $RESPONSE | jq ".totalCount")


echo "--- TEST FILTER BY ID ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?ids=000000000000001,000000000000002,000000000000003,000000000000007,000000000000008\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")

echo "--- TEST FILTER BY ID: INCLUDE-TOTAL-COUNT ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?includeTotalCount=true&ids=000000000000001,000000000000002,000000000000003,000000000000007,000000000000008\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")
assertEqual 3 $(echo $RESPONSE | jq ".totalCount")

echo "--- TEST FILTER BY STATUS ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?statuses=Active\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")

echo "--- TEST FILTER BY STATUS: INCLUDE-TOTAL-COUNT ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?includeTotalCount=true&statuses=Active\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")
assertEqual 3 $(echo $RESPONSE | jq ".totalCount")

echo "--- TEST FILTER BY STATUS ALL ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?statuses=Active,Inactive\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")


echo "--- TEST FILTER BY STATUS ALL: INCLUDE-TOTAL-COUNT ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?includeTotalCount=true&statuses=Active,Inactive\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")
assertEqual 6 $(echo $RESPONSE | jq ".totalCount")


echo "--- TEST FILTER BY STATUS/ID ALL ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?ids=000000000000001,000000000000002,000000000000003,000000000000004&statuses=Active,Whatever\""
assertEqual 2 $(echo $RESPONSE | jq ".items | length")


echo "--- TEST FILTER BY STATUS/ID ALL: INCLUDE-TOTAL-COUNT ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?includeTotalCount=true&ids=000000000000001,000000000000002,000000000000003,000000000000004&statuses=Active,Whatever\""
assertEqual 2 $(echo $RESPONSE | jq ".items | length")
assertEqual 2 $(echo $RESPONSE | jq ".totalCount")


echo "--- TEST SORT BY ID ASC ALL ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=id:ASC\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")
assertEqual \"000000000000001\" $(echo $RESPONSE | jq ".items[0].id")

echo "--- TEST SORT BY ID ASC DESC ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=id:DESC\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")
assertEqual \"000000000000006\" $(echo $RESPONSE | jq ".items[0].id")


echo "--- TEST REGULAR REQUEST ONE ROW ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/000000000000001\""
assertEqual \"000000000000001\" $(echo $RESPONSE | jq ".id")
assertEqual \"Active\" $(echo $RESPONSE | jq ".status")
assertEqual \"shortDescription-1\" $(echo $RESPONSE | jq ".shortDescription")
assertEqual \"label-1\" $(echo $RESPONSE | jq ".label")
assertEqual \"value-1\" $(echo $RESPONSE | jq ".value")
assertEqual "\"Machine Platform\"" "$(echo $RESPONSE | jq ".name")"
assertEqual \"Menu1-1\" $(echo $RESPONSE | jq ".outerMenu1")
assertEqual \"Menu2-1\" $(echo $RESPONSE | jq ".outerMenu2")









 





