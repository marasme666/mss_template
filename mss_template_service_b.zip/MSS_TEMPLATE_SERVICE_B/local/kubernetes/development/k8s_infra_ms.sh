#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: k8s_infra_ms.sh ---"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#MICROSERVICE NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
MICROSERVICE_NAME=${2:-mss-template-service-b}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${3:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
GL_HELM_RELEASE_INFRA_NAME=infra-gl

# MICROSERVICE INFRA RELEASE NAME - PLEASE NOT CHANGE IT
MS_HELM_RELEASE_INFRA_NAME=infra-ms-${MICROSERVICE_NAME}

#----------------------------------------------------------
# SET UP MICROSERVICE INFRASTRUCTURE
#----------------------------------------------------------

echo "--- GET K8S CLUSTER CONTEXT ---"

kubectl config use-context $KIND_CLUSTER_NAME

echo "--- HELM INSTALL MICROSERVICE INFRA DEPENDENCY ---"

helm --kube-context $KIND_CLUSTER_NAME status ${MS_HELM_RELEASE_INFRA_NAME} && exit 0 || true

helm --kube-context $KIND_CLUSTER_NAME dependency build ./chart

helm --kube-context $KIND_CLUSTER_NAME install ${MS_HELM_RELEASE_INFRA_NAME} ./chart 

sleep 10

cat <<EOF | kubectl --context=$KIND_CLUSTER_NAME apply -f -
kind: Role
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  namespace: default
  name: ${MICROSERVICE_NAME}-reader
rules:
  - apiGroups: [""]
    resources: ["configmaps", "pods", "services", "endpoints", "secrets"]
    verbs: ["get", "list", "watch"]
EOF

cat <<EOF | kubectl --context=$KIND_CLUSTER_NAME apply -f -
kind: RoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ${MICROSERVICE_NAME}-reader-binding
  namespace: default
subjects:
- kind: ServiceAccount
  name: ${MICROSERVICE_NAME}
  apiGroup: ""
roleRef:
  kind: Role
  name: ${MICROSERVICE_NAME}-reader
  apiGroup: ""
EOF

echo "--- SET UP MYSQL DATABASE ---"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=Ready pod/${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 --timeout=${DEFAULT_TIMEOUT}

MYSQL_PASSWORD=$(kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- printenv  | grep -i MYSQL_PASSWORD | cut -d'=' -f2)
echo $MYSQL_PASSWORD
MYSQL_USERNAME=$(kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- printenv  | grep -i MYSQL_USER | cut -d'=' -f2)
echo $MYSQL_USERNAME
MYSQL_DATABASE=$(kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- printenv  | grep -i MYSQL_DATABASE | cut -d'=' -f2)
echo $MYSQL_DATABASE


echo "--- SET UP VAULT INJECTOR ---"

kubectl --context=$KIND_CLUSTER_NAME wait --for=condition=Ready pod/${GL_HELM_RELEASE_INFRA_NAME}-vault-0 --timeout=${DEFAULT_TIMEOUT}

kubectl --context=$KIND_CLUSTER_NAME exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- vault secrets enable -path=${MICROSERVICE_NAME} -version=2 kv-v2

kubectl --context=$KIND_CLUSTER_NAME exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- vault kv put ${MICROSERVICE_NAME}/database username=$MYSQL_USERNAME  password=$MYSQL_PASSWORD database=$MYSQL_DATABASE

kubectl --context=$KIND_CLUSTER_NAME exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- vault kv put ${MICROSERVICE_NAME}/newrelic license=eu01xx4569928d7a50d54da58078cb6ee22cNRAL

kubectl --context=$KIND_CLUSTER_NAME exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- /bin/sh -c " echo 'path \"'${MICROSERVICE_NAME}'/data/database\" { capabilities = [\"list\" , \"read\"] } path \"'${MICROSERVICE_NAME}'/data/newrelic\" { capabilities = [\"list\" , \"read\"] }' | vault policy write ${MICROSERVICE_NAME} - "

kubectl --context=$KIND_CLUSTER_NAME exec -it ${GL_HELM_RELEASE_INFRA_NAME}-vault-0 -- vault write auth/kubernetes/role/${MICROSERVICE_NAME} bound_service_account_names=${MICROSERVICE_NAME} bound_service_account_namespaces=default policies=${MICROSERVICE_NAME} ttl=72h


echo "--- SET UP GITEA CHART REPOSITORY ---"

GITEA_POD_NAME=$(kubectl --context=$KIND_CLUSTER_NAME  get pods --selector=app.kubernetes.io/instance=${GL_HELM_RELEASE_INFRA_NAME},app.kubernetes.io/name=gitea --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')

kubectl --context=$KIND_CLUSTER_NAME  exec -it pod/${GITEA_POD_NAME} -- curl -X POST 'http://gitea:password@localhost:3000/api/v1/user/repos' -H 'Accept: application/json' -H 'Content-Type: application/json' -d '{ "auto_init": false, "default_branch": "master", "description": "gitops", "gitignores": "", "issue_labels": "", "license": "", "name": "'${MICROSERVICE_NAME}'", "private": false, "readme": "gitops", "template": false, "trust_model": "default" }' 














