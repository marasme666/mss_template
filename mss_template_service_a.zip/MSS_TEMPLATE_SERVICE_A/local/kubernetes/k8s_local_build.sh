#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_local_build.sh ---"
echo "-------------------------------"
echo "-------------------------------"

echo "-------------------------------"
echo "---CONFIGURATION---"
echo "-------------------------------"
echo "kind version: " $(kind version) 
echo "kind path: " $(which kind)
echo "kubectl version: " $(kubectl version)  
echo "kubectl path: " $(which kubectl)
echo "skaffold version: " $(skaffold version) 
echo "skaffold path: " $(which skaffold)
echo "helm version: " $(helm version) 
echo "helm path: " $(which helm)
echo "docker version: " $(docker version) 
echo "docker path: " $(which docker)

cd infra_gl
./k8s_infra_gl.sh
cd ..

cd infra_ci
./k8s_infra_ci.sh ${MICROSERVICE_NAME}
cd ..

cd development
./k8s_infra_ms.sh 
./k8s_development.sh
cd ..

 
