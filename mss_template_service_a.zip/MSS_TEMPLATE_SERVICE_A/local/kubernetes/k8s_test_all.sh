#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_test_all.sh ---"
echo "-------------------------------"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#MICROSERVICE NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
MICROSERVICE_NAME=${2:-mss-template-service-a}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${3:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
GL_HELM_RELEASE_INFRA_NAME=infra-gl

# MICROSERVICE INFRA RELEASE NAME - PLEASE NOT CHANGE IT
MS_HELM_RELEASE_INFRA_NAME=infra-ms-${MICROSERVICE_NAME}

#----------------------------------------------------------
# RUN TEST ON MICROSERVICE POD
#----------------------------------------------------------

cd testing

docker build -t localhost/test-client-${MICROSERVICE_NAME}:latest . 

kind load docker-image localhost/test-client-${MICROSERVICE_NAME}:latest  --name ${CLUSTER_NAME}-cluster


echo "--- RUN TEST ON POD CLIENT ---"

echo "Restarting alpine-client..."

if kubectl --context=$KIND_CLUSTER_NAME  get pod test-client-${MICROSERVICE_NAME} > /dev/null ; then
    kubectl --context=$KIND_CLUSTER_NAME  delete pod test-client-${MICROSERVICE_NAME} --grace-period=1
fi

kubectl --context=$KIND_CLUSTER_NAME  run test-client-${MICROSERVICE_NAME} --restart=Never --image=localhost/test-client-${MICROSERVICE_NAME}:latest --image-pull-policy=IfNotPresent --command -- sleep 6000000

echo "--- WAIT FOR K8S CLUSTER TO BE READY ---"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=ready pod --all --timeout=${DEFAULT_TIMEOUT}

echo "******************************"
echo "******************************"
echo "--- START FUNCTIONAL TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./functional/functional_test_script.sh test-client-${MICROSERVICE_NAME}:/tmp/functional_test_script.sh

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c "HOST=mss-template-service-a PORT=8080 /tmp/functional_test_script.sh" 

echo "******************************"
echo "******************************"
echo "--- START PERFORMANCE TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./performance/gatling test-client-${MICROSERVICE_NAME}:/opt/gatling-charts-highcharts-bundle/user-files/simulations/

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " JAVA_OPTS=\"-DHOST=mss-template-service-a -DPORT=8080 \" /opt/gatling-charts-highcharts-bundle/bin/gatling.sh -s HttpSimulationJava -nr" 

cd ..

