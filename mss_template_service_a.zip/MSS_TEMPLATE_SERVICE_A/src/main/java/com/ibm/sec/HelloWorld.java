package com.ibm.sec;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld 
{	

	@Value("${spring.application.name}")
	private String applicationName;
	
	@Autowired
	JdbcTemplate jdbcTemplate;	
	
	@GetMapping("/")
	public String hello() 
	{				
		List<String> data = jdbcTemplate.queryForList("SELECT username FROM users", String.class);
		
		return "Hello From Microservice "+applicationName+" To Team: " + data.stream().collect(Collectors.joining(","));
	}
}
