#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_test_all.sh ---"
echo "-------------------------------"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#MICROSERVICE NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
MICROSERVICE_NAME=${2:-health-check-ms}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${3:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
GL_HELM_RELEASE_INFRA_NAME=infra-gl

# MICROSERVICE INFRA RELEASE NAME - PLEASE NOT CHANGE IT
MS_HELM_RELEASE_INFRA_NAME=infra-ms-${MICROSERVICE_NAME}

#----------------------------------------------------------
# RUN TEST ON MICROSERVICE POD
#----------------------------------------------------------

cd testing

docker build -t localhost/test-client-${MICROSERVICE_NAME}:latest . 

kind load docker-image localhost/test-client-${MICROSERVICE_NAME}:latest  --name ${CLUSTER_NAME}-cluster


echo "--- RUN TEST ON POD CLIENT ---"

echo "Restarting alpine-client..."

if kubectl --context=$KIND_CLUSTER_NAME  get pod test-client-${MICROSERVICE_NAME} > /dev/null ; then
    kubectl --context=$KIND_CLUSTER_NAME  delete pod test-client-${MICROSERVICE_NAME} --grace-period=1
fi

kubectl --context=$KIND_CLUSTER_NAME  run test-client-${MICROSERVICE_NAME} --restart=Never --image=localhost/test-client-${MICROSERVICE_NAME}:latest --image-pull-policy=IfNotPresent --command -- sleep 6000000

echo "--- WAIT FOR K8S CLUSTER TO BE READY ---"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=ready pod --all --timeout=${DEFAULT_TIMEOUT}

echo "******************************"
echo "******************************"
echo "--- SET UP TEST DATABASE ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=Ready pod/${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 --timeout=${DEFAULT_TIMEOUT}

MYSQL_PASSWORD=$(kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- printenv  | grep -i MYSQL_PASSWORD | cut -d'=' -f2)
MYSQL_USERNAME=$(kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- printenv  | grep -i MYSQL_USER | cut -d'=' -f2)
MYSQL_DATABASE=$(kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- printenv  | grep -i MYSQL_DATABASE | cut -d'=' -f2)

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " echo '[client]' > /tmp/mysql.cnf"

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " echo 'user=${MYSQL_USERNAME}' >> /tmp/mysql.cnf"

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " echo 'password=${MYSQL_PASSWORD}' >> /tmp/mysql.cnf"

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " echo 'database=${MYSQL_DATABASE}' >> /tmp/mysql.cnf"

echo "******************************"
echo "******************************"
echo "--- PREPARE DATABASE FOR FUNCTIONAL TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./functional/database/functional_test_database.sql ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0:/tmp/functional_test_database.sql

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " mysql --defaults-extra-file=/tmp/mysql.cnf  --execute='source /tmp/functional_test_database.sql'"

echo "******************************"
echo "******************************"
echo "--- START FUNCTIONAL TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./functional/functional_test_script.sh test-client-${MICROSERVICE_NAME}:/tmp/functional_test_script.sh

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c "HOST=health-check-ms PORT=3333 /tmp/functional_test_script.sh" 


echo "******************************"
echo "******************************"
echo "--- PREPARE DATABASE FOR PERFORMANCE TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./performance/database/performance_test_database.sql ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0:/tmp/performance_test_database.sql

for number in {1..100}
do
echo "INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_${number}', 'NA');"
kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " echo \"INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_${number}', 'NA');\" >> /tmp/performance_test_database.sql"
done

for number in {1..100}
do
echo "INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_10${number}', ${number}, 'ALLOWED');"
kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " echo \"INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_10${number}', ${number}, 'ALLOWED');\" >> /tmp/performance_test_database.sql"
done

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " mysql --defaults-extra-file=/tmp/mysql.cnf  --execute='source /tmp/performance_test_database.sql'"

echo "******************************"
echo "******************************"
echo "--- START PERFORMANCE TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./performance/gatling test-client-${MICROSERVICE_NAME}:/opt/gatling-charts-highcharts-bundle/user-files/simulations/

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c " JAVA_OPTS=\"-DHOST=health-check-ms -DPORT=3333 \" /opt/gatling-charts-highcharts-bundle/bin/gatling.sh -s HttpSimulationJava -nr" 


echo "******************************"
echo "******************************"
echo "--- PREPARE DATABASE FOR CHAOS TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./chaos/database/chaos_test_database.sql ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0:/tmp/chaos_test_database.sql

kubectl --context=$KIND_CLUSTER_NAME exec -it ${MS_HELM_RELEASE_INFRA_NAME}-mysql-0 -- /bin/bash -c " mysql --defaults-extra-file=/tmp/mysql.cnf  --execute='source /tmp/chaos_test_database.sql'"

echo "******************************"
echo "******************************"
echo "--- START APPLICATION CHAOS TEST ---"
echo "******************************"
echo "******************************"

kubectl --context=$KIND_CLUSTER_NAME cp ./chaos/chaos_test_script.sh test-client-${MICROSERVICE_NAME}:/tmp/chaos_test_script.sh

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c "HOST=health-check-ms PORT=3333 /tmp/chaos_test_script.sh" 

echo "******************************"
echo "******************************"
echo "--- START KUBERNETES CHAOS TEST ---"
echo "******************************"
echo "******************************"

GITEA_POD_NAME=$(kubectl --context=$KIND_CLUSTER_NAME get pods --selector=app.kubernetes.io/instance=${GL_HELM_RELEASE_INFRA_NAME},app.kubernetes.io/name=gitea --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')


echo "--- UPDATE GITEA MICROSERVICE REPOSITORY---"

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- rm -rf /tmp/microservice

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- git clone http://gitea:password@localhost:3000/gitea/microservice.git /tmp/microservice

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- mkdir -p /tmp/microservice/${MICROSERVICE_NAME} 

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- rm -rf /tmp/microservice/${MICROSERVICE_NAME}/chart/templates/deployment.yaml

kubectl --context=$KIND_CLUSTER_NAME cp ../microservice/chaos/chart/templates/deployment.yaml ${GITEA_POD_NAME}:/tmp/microservice/${MICROSERVICE_NAME}/chart/templates/

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- /bin/sh -c " cd /tmp/microservice/${MICROSERVICE_NAME} && git add . &&  git commit -m 'development' && git push origin master || true "

helm --kube-context $KIND_CLUSTER_NAME uninstall ${MICROSERVICE_NAME}

sleep 180

kubectl --context=$KIND_CLUSTER_NAME cp ./functional/functional_test_script.sh test-client-${MICROSERVICE_NAME}:/tmp/functional_test_script.sh

kubectl --context=$KIND_CLUSTER_NAME exec -it test-client-${MICROSERVICE_NAME} -- /bin/bash -c "HOST=health-check-ms PORT=3333 /tmp/functional_test_script.sh" 


cd ..

