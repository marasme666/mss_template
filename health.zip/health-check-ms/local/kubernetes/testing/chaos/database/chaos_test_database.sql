
DROP TABLE IF EXISTS `health_check` CASCADE;

DROP TABLE IF EXISTS `health_check_tool` CASCADE;

CREATE TABLE IF NOT EXISTS `health_check_tool` (
  `health_check_tool_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `health_check_tool_name` varchar(255) NOT NULL,
  `manager_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`health_check_tool_id`),
  UNIQUE KEY `health_check_tool_name` (`health_check_tool_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `health_check` (
  `health_check_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `health_check_name` varchar(255) NOT NULL,
  `health_check_tool_id` int(10) unsigned DEFAULT NULL,
  `severity` enum('ALLOWED','INFO','LOW','MEDIUM','HIGH','UNKNOWN') NOT NULL,
  PRIMARY KEY (`health_check_id`),
  UNIQUE KEY `health_check_name_tool` (`health_check_name`,`health_check_tool_id`),
  KEY `health_check_fk_1` (`health_check_tool_id`),
  CONSTRAINT `health_check_fk_1` FOREIGN KEY (`health_check_tool_id`) REFERENCES `health_check_tool` (`health_check_tool_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;


INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_1', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_2', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_3', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_4', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_5', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_6', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_7', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_8', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_9', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_10', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_11', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_12', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_13', 'NA');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_101', 1, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_102', 2, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_103', 3, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_104', 4, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_105', 5, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_106', 6, 'UNKNOWN');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_107', 7, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_108', 8, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_109', 9, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_110', 10, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_111', 11, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_112', 12, 'UNKNOWN');

