#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: test_script.sh ---"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

: ${PROTOCOL=http}
: ${HOST=localhost}
: ${PORT=3333}
: ${URLPATH=health-check}

#----------------------------------------------------------
#  HELP FUNCTIONS
#----------------------------------------------------------

function assertCurl() {

  local expectedHttpCode=$1
  local curlCmd="$2 -w \"%{http_code}\""
  local result=$(eval $curlCmd)
  local httpCode="${result:(-3)}"
  RESPONSE='' && (( ${#result} > 3 )) && RESPONSE="${result%???}"

  if [ "$httpCode" = "$expectedHttpCode" ]
  then
    if [ "$httpCode" = "200" ]
    then
      echo "Test OK (HTTP Code: $httpCode)"
    else
      echo "Test OK (HTTP Code: $httpCode, $RESPONSE)"
    fi
  else
    echo  "Test FAILED, EXPECTED HTTP Code: $expectedHttpCode, GOT: $httpCode, WILL ABORT!"
    echo  "- Failing command: $curlCmd"
    echo  "- Response Body: $RESPONSE"
    exit 1
  fi
}

function assertEqual() {

  local expected=$1
  local actual=$2

  if [ "$actual" = "$expected" ]
  then
    echo "Test OK (actual value: $actual)"
  else
    echo "Test FAILED, EXPECTED VALUE: $expected, ACTUAL VALUE: $actual, WILL ABORT"
    exit 1
  fi
}

function testUrl() {
  url=$@
  if $url -ks -f -o /dev/null
  then
    return 0
  else
    return 1
  fi;
}

function waitForService() {
  url=$@
  echo -n "Wait for: $url... "
  n=0
  until testUrl $url
  do
    n=$((n + 1))
    if [[ $n == 100 ]]
    then
      echo " Give up"
      exit 1
    else
      sleep 3
      echo -n ", retry #$n "
    fi
  done
  echo "DONE, continues..."
}

#----------------------------------------------------------
#  START END TO END TESTING
#----------------------------------------------------------

echo "----------------------------------------------------------"
echo "--- START TESTING ---"
echo "----------------------------------------------------------"

# Wait for microservice to be ready
waitForService curl $PROTOCOL://$HOST:$PORT/actuator/health


#----------------------------------------------------------
#  GET TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- GET TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST REGULAR REQUEST ALL ROWS ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/\""
assertEqual 12 $(echo $RESPONSE | jq ".items | length")
assertEqual 12 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")

echo "--- TEST REGULAR REQUEST ONE ROW: ALLOWED ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/100\""
assertEqual 100 $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_101\" $(echo $RESPONSE | jq ".name")
assertEqual 1  $(echo $RESPONSE | jq ".toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_1\"  $(echo $RESPONSE | jq ".toolName")
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")

echo "--- TEST REGULAR REQUEST ONE ROW: INFO ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/101\""
assertEqual 101 $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_102\" $(echo $RESPONSE | jq ".name")
assertEqual 2  $(echo $RESPONSE | jq ".toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_2\"  $(echo $RESPONSE | jq ".toolName")
assertEqual \"INFO\"  $(echo $RESPONSE | jq ".severity")

echo "--- TEST REGULAR REQUEST WITH PAGINATION PAGE=0 ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?start=0&limit=6\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")
assertEqual 6 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 2  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")

echo "--- TEST REGULAR REQUEST WITH PAGINATION PAGE=1 ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?start=1&limit=6\""
assertEqual 6 $(echo $RESPONSE | jq ".items | length")
assertEqual 6 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 2  $(echo $RESPONSE | jq ".totalPages")
assertEqual 1  $(echo $RESPONSE | jq ".start")

echo "--- TEST REGULAR REQUEST WITH FILTER IDS=100,101,102 ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?ids=100,101,102\""
assertEqual 3 $(echo $RESPONSE | jq ".items | length")
assertEqual 3 $(echo $RESPONSE | jq ".limit")
assertEqual 3 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual 100  $(echo $RESPONSE | jq ".items[0].id")
assertEqual 101  $(echo $RESPONSE | jq ".items[1].id")
assertEqual 102  $(echo $RESPONSE | jq ".items[2].id")

echo "--- TEST REGULAR REQUEST WITH FILTER SEVERITIES=MEDIUM,HIGH ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?severities=MEDIUM,HIGH\""
assertEqual 4 $(echo $RESPONSE | jq ".items | length")
assertEqual 4 $(echo $RESPONSE | jq ".limit")
assertEqual 4 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")
assertEqual \"HIGH\"  $(echo $RESPONSE | jq ".items[1].severity")
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[2].severity")
assertEqual \"HIGH\"  $(echo $RESPONSE | jq ".items[3].severity")

echo "--- TEST REGULAR REQUEST WITH FILTER NAMES=HEALTH_CHECK_NAME_104,HEALTH_CHECK_NAME_105 ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?names=HEALTH_CHECK_NAME_104,HEALTH_CHECK_NAME_105\""
assertEqual 2 $(echo $RESPONSE | jq ".items | length")
assertEqual 2 $(echo $RESPONSE | jq ".limit")
assertEqual 2 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual \"HEALTH_CHECK_NAME_104\"  $(echo $RESPONSE | jq ".items[0].name")
assertEqual \"HEALTH_CHECK_NAME_105\"  $(echo $RESPONSE | jq ".items[1].name")

echo "--- TEST REGULAR REQUEST WITH FILTER TOOLIDS=7,8 ---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?toolIds=7,8\""
assertEqual 2 $(echo $RESPONSE | jq ".items | length")
assertEqual 2 $(echo $RESPONSE | jq ".limit")
assertEqual 2 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual 7  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_7\"  $(echo $RESPONSE | jq ".items[0].toolName")
assertEqual 8  $(echo $RESPONSE | jq ".items[1].toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_8\"  $(echo $RESPONSE | jq ".items[1].toolName")

echo "--- TEST REGULAR REQUEST ALL ROWS SORT BY ID ASC---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=id.ASC\""
assertEqual 12 $(echo $RESPONSE | jq ".items | length")
assertEqual 12 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual 100  $(echo $RESPONSE | jq ".items[0].id")

echo "--- TEST REGULAR REQUEST ALL ROWS SORT BY ID DESC---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=id.DESC\""
assertEqual 12 $(echo $RESPONSE | jq ".items | length")
assertEqual 12 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual 111  $(echo $RESPONSE | jq ".items[0].id")

echo "--- TEST REGULAR REQUEST ALL ROWS SORT BY HEALTHCHECKNAME ASC---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=name.ASC\""
assertEqual 12 $(echo $RESPONSE | jq ".items | length")
assertEqual 12 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual \"HEALTH_CHECK_NAME_101\"  $(echo $RESPONSE | jq ".items[0].name")

echo "--- TEST REGULAR REQUEST ALL ROWS SORT BY HEALTHCHECKNAME DESC---"
assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=name.DESC\""
assertEqual 12 $(echo $RESPONSE | jq ".items | length")
assertEqual 12 $(echo $RESPONSE | jq ".limit")
assertEqual 12 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")
assertEqual \"HEALTH_CHECK_NAME_112\"  $(echo $RESPONSE | jq ".items[0].name")

 
#----------------------------------------------------------
#  POST TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- POST TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST POST REQUEST ---"
assertCurl 201 "curl -X POST \"$PROTOCOL://$HOST:$PORT/$URLPATH/\" -H 'Content-Type: application/json' -d '{ \"name\":\"HEALTH_CHECK_NAME_113\", \"toolId\":13, \"severity\":\"INFO\" }' "
postId=$(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_113\" $(echo $RESPONSE | jq ".name")
assertEqual 13  $(echo $RESPONSE | jq ".toolId")
assertEqual \"INFO\"  $(echo $RESPONSE | jq ".severity")

assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_113\" $(echo $RESPONSE | jq ".name")
assertEqual 13  $(echo $RESPONSE | jq ".toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_13\"  $(echo $RESPONSE | jq ".toolName")
assertEqual \"INFO\"  $(echo $RESPONSE | jq ".severity")

#----------------------------------------------------------
#  PUT TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- PUT TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST PUT REQUEST ---"
assertCurl 200 "curl -X PUT \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\" -H 'Content-Type: application/json' -d '{ \"name\":\"HEALTH_CHECK_NAME_113_PUT\", \"toolId\":13, \"severity\":\"ALLOWED\" }' "
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_113_PUT\" $(echo $RESPONSE | jq ".name")
assertEqual 13  $(echo $RESPONSE | jq ".toolId")
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")

assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_113_PUT\" $(echo $RESPONSE | jq ".name")
assertEqual 13  $(echo $RESPONSE | jq ".toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_13\"  $(echo $RESPONSE | jq ".toolName")
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")


assertCurl 200 "curl -X PUT \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\" -H 'Content-Type: application/json' -d '{ \"name\":\"HEALTH_CHECK_NAME_113_PUT\", \"toolId\":12, \"severity\":\"ALLOWED\" }' "
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_113_PUT\" $(echo $RESPONSE | jq ".name")
assertEqual 12  $(echo $RESPONSE | jq ".toolId")
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")

assertCurl 200 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"HEALTH_CHECK_NAME_113_PUT\" $(echo $RESPONSE | jq ".name")
assertEqual 12  $(echo $RESPONSE | jq ".toolId")
assertEqual \"HEALTH_CHECK_TOOL_NAME_12\"  $(echo $RESPONSE | jq ".toolName")
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")


#----------------------------------------------------------
#  DELETE TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- DELETE TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST DELETE REQUEST ---"
assertCurl 204 "curl -X DELETE \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\" -H 'Content-Type: application/json' "
assertCurl 404 "curl \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""




