#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_infra_ci.sh ---"
echo "-------------------------------"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${2:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
CI_HELM_RELEASE_INFRA_NAME=infra-ci

#----------------------------------------------------------
# SET UP CI INFRASTRUCTURE
#----------------------------------------------------------

kubectl config use-context $KIND_CLUSTER_NAME

echo "--- HELM INSTALL DEPENDENCY ---"

helm --kube-context $KIND_CLUSTER_NAME status ${CI_HELM_RELEASE_INFRA_NAME} && exit 0 || true

helm --kube-context $KIND_CLUSTER_NAME dependency build ./chart

helm --kube-context $KIND_CLUSTER_NAME install ${CI_HELM_RELEASE_INFRA_NAME} ./chart 

sleep 10


