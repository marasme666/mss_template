#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: Functional_Test_Script_dal09_dev_services.sh ---"
echo "-------------------------------"


#----------------------------------------------------------
#  DYNAMIC VARIABLES PASSED AS SCRIPT ARGUMENTS (-u USERNAME -p PASSWORD or -t JWTTOKEN)
#----------------------------------------------------------
while getopts u:p:t: option
do 
    case "${option}"
        in
        u)USERNAME=${OPTARG};;
        p)PASSWORD=${OPTARG};;
        t)JWTTOKEN=${OPTARG};;
    esac
done


#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------
: ${PROTOCOL=https}
: ${HOST=dal09-dev-services.sec.ibm.com}
: ${PORT=443}
: ${URLPATH=micro/health-check}

if [ "$JWTTOKEN" = "" ]
then
# BASIC AUTHENTICATION
AUTHENTICATION="-u $USERNAME:$PASSWORD"

else
# TOKEN AUTHENTICATION
AUTHENTICATION="-H 'Authorization: Bearer $JWTTOKEN'"

fi



#----------------------------------------------------------
#  HELP FUNCTIONS
#----------------------------------------------------------

function assertCurl() {

  local expectedHttpCode=$1
  local curlCmd="$2 -w \"%{http_code}\""
  local result=$(eval $curlCmd)
  local httpCode="${result:(-3)}"
  RESPONSE='' && (( ${#result} > 3 )) && RESPONSE="${result%???}"

  if [ "$httpCode" = "$expectedHttpCode" ]
  then
    if [ "$httpCode" = "200" ]
    then
      echo "Test OK (HTTP Code: $httpCode)"
    else
      echo "Test OK (HTTP Code: $httpCode, $RESPONSE)"
    fi
  else
    echo  "Test FAILED, EXPECTED HTTP Code: $expectedHttpCode, GOT: $httpCode, WILL ABORT!"
    echo  "- Failing command: $curlCmd"
    echo  "- Response Body: $RESPONSE"
    exit 1
  fi
}

function assertEqual() {

  local expected=$1
  local actual=$2

  if [ "$actual" = "$expected" ]
  then
    echo "Test OK (actual value: $actual)"
  else
    echo "Test FAILED, EXPECTED VALUE: $expected, ACTUAL VALUE: $actual, WILL ABORT"
    exit 1
  fi
}

function testUrl() {
  url=$@
  if $url -ks -f -o /dev/null
  then
    return 0
  else
    return 1
  fi;
}

function waitForService() {
  url=$@
  echo -n "Wait for: $url... "
  n=0
  until testUrl $url
  do
    n=$((n + 1))
    if [[ $n == 100 ]]
    then
      echo " Give up"
      exit 1
    else
      sleep 3
      echo -n ", retry #$n "
    fi
  done
  echo "DONE, continues..."
}

#----------------------------------------------------------
#  START END TO END TESTING
#----------------------------------------------------------

echo "----------------------------------------------------------"
echo "--- START TESTING ---"
echo "----------------------------------------------------------"

#----------------------------------------------------------
#  GET TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- GET TESTING ---"
echo "----------------------------------------------------------"
echo "-----------------------------------"
echo "--------- GET ALL ROWS ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/\""

assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")

assertEqual 8  $(echo $RESPONSE | jq ".items[1].id")
assertEqual "\"Check 2\""  "$(echo $RESPONSE | jq ".items[1].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[1].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[1].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[1].severity")

echo "-----------------------------------"
echo "--------- GET ONE ROW BY ID ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/7\""

assertEqual 7 $(echo $RESPONSE | jq ".id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".name")"
assertEqual 6  $(echo $RESPONSE | jq ".toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".severity")

echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH PAGINATION - PAGE 0------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?start=0&limit=1\""

assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")

echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH PAGINATION - PAGE 1------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?start=1&limit=1\""

assertEqual 8  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 2\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")


echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER IDS(EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?ids=7\""

assertEqual 1 $(echo $RESPONSE | jq ".items | length")
assertEqual 1 $(echo $RESPONSE | jq ".limit")
assertEqual 1 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")


assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")



echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER IDS(NOT EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?ids=1\""

assertEqual 0 $(echo $RESPONSE | jq ".items | length")
assertEqual 0 $(echo $RESPONSE | jq ".limit")
assertEqual 0 $(echo $RESPONSE | jq ".totalCount")
assertEqual 0  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")


echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER SEVERITIES(EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?severities=MEDIUM\""

assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")

assertEqual 8  $(echo $RESPONSE | jq ".items[1].id")
assertEqual "\"Check 2\""  "$(echo $RESPONSE | jq ".items[1].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[1].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[1].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[1].severity")

echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER SEVERITIES(NOT EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?severities=HIGH\""

assertEqual 0 $(echo $RESPONSE | jq ".items | length")
assertEqual 0 $(echo $RESPONSE | jq ".limit")
assertEqual 0 $(echo $RESPONSE | jq ".totalCount")
assertEqual 0  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")


echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER NAMES(EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?names=Check%201\""

assertEqual 1 $(echo $RESPONSE | jq ".items | length")
assertEqual 1 $(echo $RESPONSE | jq ".limit")
assertEqual 1 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")


assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")


echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER NAMES(NOT-EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?names=notexists\""

assertEqual 0 $(echo $RESPONSE | jq ".items | length")
assertEqual 0 $(echo $RESPONSE | jq ".limit")
assertEqual 0 $(echo $RESPONSE | jq ".totalCount")
assertEqual 0  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")


echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER TOOLIDS(EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?toolIds=6\""

assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")

assertEqual 8  $(echo $RESPONSE | jq ".items[1].id")
assertEqual "\"Check 2\""  "$(echo $RESPONSE | jq ".items[1].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[1].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[1].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[1].severity")

echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH FILTER TOOLIDS(NOT-EXISTS) ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?toolIds=0\""

assertEqual 0 $(echo $RESPONSE | jq ".items | length")
assertEqual 0 $(echo $RESPONSE | jq ".limit")
assertEqual 0 $(echo $RESPONSE | jq ".totalCount")
assertEqual 0  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")


echo "-----------------------------------"
echo "--------- GET ALL ROWS WITH MULTIPLE FILTERS ACTIVE ------------"
echo "-----------------------------------"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?ids=7&names=Check%202\""

assertEqual 2 $(echo $RESPONSE | jq ".items | length")
assertEqual 2 $(echo $RESPONSE | jq ".limit")
assertEqual 2 $(echo $RESPONSE | jq ".totalCount")
assertEqual 1  $(echo $RESPONSE | jq ".totalPages")
assertEqual 0  $(echo $RESPONSE | jq ".start")

assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[0].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[0].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[0].severity")

assertEqual 8  $(echo $RESPONSE | jq ".items[1].id")
assertEqual "\"Check 2\""  "$(echo $RESPONSE | jq ".items[1].name")"
assertEqual 6  $(echo $RESPONSE | jq ".items[1].toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".items[1].toolName")"
assertEqual \"MEDIUM\"  $(echo $RESPONSE | jq ".items[1].severity")


echo "--- TEST REGULAR REQUEST ALL ROWS SORT BY ID ASC---"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=id.ASC\""
assertEqual 7  $(echo $RESPONSE | jq ".items[0].id")


echo "--- TEST REGULAR REQUEST ALL ROWS SORT BY HEALTHCHECKNAME ASC---"
assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/?sort=name.ASC\""
assertEqual "\"Check 1\""  "$(echo $RESPONSE | jq ".items[0].name")"

#----------------------------------------------------------
#  POST TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- POST TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST POST REQUEST ---"
timestamp=$(date +"%s")
assertCurl 201 "curl $AUTHENTICATION -X POST \"$PROTOCOL://$HOST:$PORT/$URLPATH/\" -H 'Content-Type: application/json' -d '{ \"name\":\"TEST_HEALTH_CHECK_NAME_POST_$timestamp\", \"toolId\":6, \"severity\":\"INFO\" }' "
postId=$(echo $RESPONSE | jq ".id")
assertEqual \"TEST_HEALTH_CHECK_NAME_POST_$timestamp\" $(echo $RESPONSE | jq ".name")
assertEqual 6  $(echo $RESPONSE | jq ".toolId")
assertEqual \"INFO\"  $(echo $RESPONSE | jq ".severity")

assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"TEST_HEALTH_CHECK_NAME_POST_$timestamp\" $(echo $RESPONSE | jq ".name")
assertEqual 6  $(echo $RESPONSE | jq ".toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".toolName")"
assertEqual \"INFO\"  $(echo $RESPONSE | jq ".severity")

#----------------------------------------------------------
#  PUT TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- PUT TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST PUT REQUEST ---"
assertCurl 200 "curl $AUTHENTICATION -X PUT \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\" -H 'Content-Type: application/json' -d '{ \"name\":\"TEST_HEALTH_CHECK_NAME_PUT_$timestamp\", \"toolId\":6, \"severity\":\"ALLOWED\" }' "
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"TEST_HEALTH_CHECK_NAME_PUT_$timestamp\" $(echo $RESPONSE | jq ".name")
assertEqual 6  $(echo $RESPONSE | jq ".toolId")
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")

assertCurl 200 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""
assertEqual $postId $(echo $RESPONSE | jq ".id")
assertEqual \"TEST_HEALTH_CHECK_NAME_PUT_$timestamp\" $(echo $RESPONSE | jq ".name")
assertEqual 6  $(echo $RESPONSE | jq ".toolId")
assertEqual "\"Test Health Check Tool\""  "$(echo $RESPONSE | jq ".toolName")"
assertEqual \"ALLOWED\"  $(echo $RESPONSE | jq ".severity")

#----------------------------------------------------------
#  DELETE TESTING 
#----------------------------------------------------------
echo "----------------------------------------------------------"
echo "--- DELETE TESTING ---"
echo "----------------------------------------------------------"
echo "--- TEST DELETE REQUEST ---"
assertCurl 204 "curl $AUTHENTICATION -X DELETE \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\" -H 'Content-Type: application/json' "
assertCurl 404 "curl $AUTHENTICATION \"$PROTOCOL://$HOST:$PORT/$URLPATH/$postId\""
