

import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

public class Functional_dal09_dev_services_Test extends Simulation
{
	  String urlPath = "/micro/health-check/";
	  
	  String protocol = System.getProperty("PROTOCOL", "https");
	
	  String host = System.getProperty("HOST", "dal09-dev-services.sec.ibm.com");
	  
	  String port = System.getProperty("PORT", "443");	
	  
	  String username = System.getProperty("USERNAME","");
	  
	  String password = System.getProperty("PASSWORD", "");
	  
	  String token = System.getProperty("TOKEN", "");
	  
	  String timestamp = Long.toString(System.currentTimeMillis());
	  	  
	  // Basic Authentication	
	  HttpProtocolBuilder httpConfBasicAuth = http.baseUrl(protocol+"://"+host+":"+port)
			  .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
			  .contentTypeHeader("application/json")
			  .basicAuth(username, password);
	  
	  // Token Authentication
	  HttpProtocolBuilder httpConfTokenAuth = http.baseUrl(protocol+"://"+host+":"+port)
	  		  .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	  		  .contentTypeHeader("application/json")
	  		  .authorizationHeader("Bearer " + token);
	  
	  
	  
	  ScenarioBuilder scn = scenario("REST-Simulation")    
	    //********************************
	    //GET	  
        //********************************	  
		.exec(
			http("[GET] Get All Requests")
		    .get(urlPath)
		    .check(jsonPath("$.items[0].id").ofInt().is(7))
		    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
		    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
		    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
		    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))
		    .check(jsonPath("$.items[1].id").ofInt().is(8))
		    .check(jsonPath("$.items[1].name").ofString().is("Check 2"))
		    .check(jsonPath("$.items[1].toolId").ofInt().is(6))
		    .check(jsonPath("$.items[1].toolName").ofString().is("Test Health Check Tool"))
		    .check(jsonPath("$.items[1].severity").ofString().is("MEDIUM"))	    
		    .check(status().is(200))
		    )
	    
	    .exec(
	    	http("[GET] Get One Row By Id")
	    	.get(urlPath+"7")
		    .check(jsonPath("$.id").ofInt().is(7))
		    .check(jsonPath("$.name").ofString().is("Check 1"))
		    .check(jsonPath("$.toolId").ofInt().is(6))
		    .check(jsonPath("$.toolName").ofString().is("Test Health Check Tool"))
		    .check(jsonPath("$.severity").ofString().is("MEDIUM"))	    	
	    	.check(status().is(200))
	    )
	    
	    .exec(
		    	http("[GET] Get All Rows with Pagination - Page 0")
		    	.get(urlPath+"?start=0&limit=1")
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))  	
		    	.check(status().is(200))
		    )
	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Pagination - Page 1")
		    	.get(urlPath+"?start=1&limit=1")
			    .check(jsonPath("$.items[0].id").ofInt().is(8))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 2"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))  	
		    	.check(status().is(200))
		    )
	        
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter Ids - Active")
		    	.get(urlPath+"?ids=7")
		    	.check(jsonPath("$.limit").ofInt().is(1))
		    	.check(jsonPath("$.totalCount").ofInt().is(1))
		    	.check(jsonPath("$.totalPages").ofInt().is(1))
		    	.check(jsonPath("$.start").ofInt().is(0))
		    	
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))	
		    	.check(status().is(200))
		    )
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter Ids - Not Active")
		    	.get(urlPath+"?ids=1")
		    	.check(jsonPath("$.limit").ofInt().is(0))
		    	.check(jsonPath("$.totalCount").ofInt().is(0))
		    	.check(jsonPath("$.totalPages").ofInt().is(0))
		    	.check(jsonPath("$.start").ofInt().is(0))
		    	
		    	.check(status().is(200))
		    )	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter Severities - Active")
		    	.get(urlPath+"?severities=MEDIUM")
		    	
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))
			    .check(jsonPath("$.items[1].id").ofInt().is(8))
			    .check(jsonPath("$.items[1].name").ofString().is("Check 2"))
			    .check(jsonPath("$.items[1].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[1].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[1].severity").ofString().is("MEDIUM"))	  	
		    	.check(status().is(200))
		    )	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter Severities - Not Active")
		    	.get(urlPath+"?severities=HIGH")
		    	.check(jsonPath("$.limit").ofInt().is(0))
		    	.check(jsonPath("$.totalCount").ofInt().is(0))
		    	.check(jsonPath("$.totalPages").ofInt().is(0))
		    	.check(jsonPath("$.start").ofInt().is(0))
		    	
		    	.check(status().is(200))
		    )	
	    
	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter Names - Active")
		    	.get(urlPath+"?names=Check%201")
		    	
		    	.check(jsonPath("$.limit").ofInt().is(1))
		    	.check(jsonPath("$.totalCount").ofInt().is(1))
		    	.check(jsonPath("$.totalPages").ofInt().is(1))
		    	.check(jsonPath("$.start").ofInt().is(0))
		    	
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))	 
			    
		    	.check(status().is(200))
		    )	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter Names - Not Active")
		    	.get(urlPath+"?names=notexists")
		    	.check(jsonPath("$.limit").ofInt().is(0))
		    	.check(jsonPath("$.totalCount").ofInt().is(0))
		    	.check(jsonPath("$.totalPages").ofInt().is(0))
		    	.check(jsonPath("$.start").ofInt().is(0))
		    	
		    	.check(status().is(200))
		    )	    
	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter ToolIds - Active")
		    	.get(urlPath+"?toolIds=6")
		    	
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))
			    .check(jsonPath("$.items[1].id").ofInt().is(8))
			    .check(jsonPath("$.items[1].name").ofString().is("Check 2"))
			    .check(jsonPath("$.items[1].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[1].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[1].severity").ofString().is("MEDIUM"))	
			    
		    	.check(status().is(200))
		    )	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Filter ToolIds - Not Active")
		    	.get(urlPath+"?toolIds=0")
		    	.check(jsonPath("$.limit").ofInt().is(0))
		    	.check(jsonPath("$.totalCount").ofInt().is(0))
		    	.check(jsonPath("$.totalPages").ofInt().is(0))
		    	.check(jsonPath("$.start").ofInt().is(0))
		    	
		    	.check(status().is(200))
		    )	
	    
	    
	    .exec(
		    	http("[GET] Get All Rows with Multiple Filters - Active")
		    	.get(urlPath+"?ids=7&names=Check%202")
		    	
		    	.check(jsonPath("$.limit").ofInt().is(2))
		    	.check(jsonPath("$.totalCount").ofInt().is(2))
		    	.check(jsonPath("$.totalPages").ofInt().is(1))
		    	.check(jsonPath("$.start").ofInt().is(0))		    	
		    	
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    .check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    .check(jsonPath("$.items[0].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[0].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[0].severity").ofString().is("MEDIUM"))
			    .check(jsonPath("$.items[1].id").ofInt().is(8))
			    .check(jsonPath("$.items[1].name").ofString().is("Check 2"))
			    .check(jsonPath("$.items[1].toolId").ofInt().is(6))
			    .check(jsonPath("$.items[1].toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.items[1].severity").ofString().is("MEDIUM"))	
			    
		    	.check(status().is(200))
		    )	    
	    
	    .exec(
		    	http("[GET] Get All Rows Sort By - id.ASC")
		    	.get(urlPath+"?sort=id.ASC")
		    	
	 		    	
			    .check(jsonPath("$.items[0].id").ofInt().is(7))
			    
		    	.check(status().is(200))
		    )		    
	    
	    .exec(
		    	http("[GET] Get All Rows Sort By - name.ASC")
		    	.get(urlPath+"?sort=name.ASC")
		    	
	 		    	
		    	.check(jsonPath("$.items[0].name").ofString().is("Check 1"))
			    
		    	.check(status().is(200))
		    )
	    
	    //********************************
	    //POST	  
        //********************************	    
	    
	    .exec(
				http("[POST] Add Row")
				.post(urlPath)
				.body(StringBody("{ \"name\":\"TEST_HEALTH_CHECK_NAME_POST_"+timestamp+"\", \"toolId\":6, \"severity\":\"INFO\" }"))
				.check(jsonPath("$.id").saveAs("healthCheckId"))
				.check(status().is(201))
			  )

	    .exec(
		    	http("[POST] Check if Row has been added")
		    	.get(urlPath+"#{healthCheckId}")
		    	.check(jsonPath("$.id").ofInt().is(session -> session.getInt("healthCheckId")))
			    .check(jsonPath("$.name").ofString().is("TEST_HEALTH_CHECK_NAME_POST_"+timestamp))
			    .check(jsonPath("$.toolId").ofInt().is(6))
			    .check(jsonPath("$.toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.severity").ofString().is("INFO"))			    	
		    	.check(status().is(200))
		     )
	    
	    //********************************
	    //PUT	  
        //********************************		    
	    
	    .exec(
				http("[PUT] Update Row")
				.put(urlPath+"#{healthCheckId}")
				.body(StringBody("{ \"name\":\"TEST_HEALTH_CHECK_NAME_PUT_"+timestamp+"\", \"toolId\":6, \"severity\":\"ALLOWED\" }"))
				.check(status().is(200))
			  )    
	    .exec(
		    	http("[PUT] Check if Row has been updated")
		    	.get(urlPath+"#{healthCheckId}")
		    	.check(jsonPath("$.id").ofInt().is(session -> session.getInt("healthCheckId")))
			    .check(jsonPath("$.name").ofString().is("TEST_HEALTH_CHECK_NAME_PUT_"+timestamp))
			    .check(jsonPath("$.toolId").ofInt().is(6))
			    .check(jsonPath("$.toolName").ofString().is("Test Health Check Tool"))
			    .check(jsonPath("$.severity").ofString().is("ALLOWED"))			    	
		    	.check(status().is(200))
		    )
	    
	    //********************************
	    //DELETE	  
        //********************************		    
	    .exec(
				http("[DELETE] Delete Row")
				.delete(urlPath+"#{healthCheckId}")
				.check(status().is(204))
			  )    
	    .exec(
		    	http("[DELETE] Check if Row has been deleted")
		    	.get(urlPath+"#{healthCheckId}")   	
		    	.check(status().is(404))
		    )		    
	    ;
	  	  
	  {
		if(token.isEmpty())
		{
		    setUp
		    (
		    	scn.injectOpen(atOnceUsers(1))
		    )
		    .protocols(httpConfBasicAuth);				
		
		}
		
		else
		{
		    setUp
		    (
		    	scn.injectOpen(atOnceUsers(1))
		    )
		    .protocols(httpConfTokenAuth);			
		}

	  }
}
