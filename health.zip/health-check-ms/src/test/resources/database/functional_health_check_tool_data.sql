INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_1', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_2', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_3', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_4', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_5', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_6', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_7', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_8', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_9', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_10', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_11', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_12', 'NA');

INSERT INTO health_check_tool (health_check_tool_name, manager_name) VALUES('HEALTH_CHECK_TOOL_NAME_13', 'NA');
