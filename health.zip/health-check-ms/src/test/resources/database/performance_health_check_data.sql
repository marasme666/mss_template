
INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_101', 1, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_102', 2, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_103', 3, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_104', 4, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_105', 5, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_106', 6, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_107', 7, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_108', 8, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_109', 9, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_110', 10, 'MEDIUM');




INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_111', 11, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_112', 12, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_113', 13, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_114', 14, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_115', 15, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_116', 16, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_117', 17, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_118', 18, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_119', 19, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_120', 20, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_121', 21, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_122', 22, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_123', 23, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_124', 24, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_125', 25, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_126', 26, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_127', 27, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_128', 28, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_129', 29, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_130', 30, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_131', 31, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_132', 32, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_133', 33, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_134', 34, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_135', 35, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_136', 36, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_137', 37, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_138', 38, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_139', 39, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_140', 40, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_141', 41, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_142', 42, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_143', 43, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_144', 44, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_145', 45, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_146', 46, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_147', 47, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_148', 48, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_149', 49, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_150', 50, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_151', 51, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_152', 52, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_153', 53, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_154', 54, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_155', 55, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_156', 56, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_157', 57, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_158', 58, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_159', 59, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_160', 60, 'MEDIUM');



INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_161', 61, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_162', 62, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_163', 63, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_164', 64, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_165', 65, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_166', 66, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_167', 67, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_168', 68, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_169', 69, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_170', 70, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_171', 71, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_172', 72, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_173', 73, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_174', 74, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_175', 75, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_176', 76, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_177', 77, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_178', 78, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_179', 79, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_180', 80, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_181', 81, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_182', 82, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_183', 83, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_184', 84, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_185', 85, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_186', 86, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_187', 87, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_188', 88, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_189', 89, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_190', 90, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_191', 91, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_192', 92, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_193', 93, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_194', 94, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_195', 95, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_196', 96, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_197', 97, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_198', 98, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_199', 99, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_200', 100, 'MEDIUM');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_201', 101, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_202', 102, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_203', 103, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_204', 104, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_205', 105, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_206', 106, 'UNKNOWN');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_207', 107, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_208', 108, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_209', 109, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_210', 110, 'MEDIUM');