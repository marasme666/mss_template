
INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_101', 1, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_102', 2, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_103', 3, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_104', 4, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_105', 5, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_106', 6, 'UNKNOWN');


INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_107', 7, 'ALLOWED');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_108', 8, 'INFO');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_109', 9, 'LOW');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_110', 10, 'MEDIUM');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_111', 11, 'HIGH');

INSERT INTO health_check (health_check_name, health_check_tool_id, severity) VALUES('HEALTH_CHECK_NAME_112', 12, 'UNKNOWN');
