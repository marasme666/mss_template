package com.ibm.sec.healthcheckms.integration.controller;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.jdbc.DataSourceHealthIndicator;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import lombok.extern.slf4j.Slf4j;


@Tag("Integration")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Sql(scripts = {"classpath:database/schema.sql", "classpath:database/functional_health_check_tool_data.sql", "classpath:database/functional_health_check_data.sql"})
@TestPropertySource(properties = {"spring.jpa.hibernate.ddl-auto=none", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL57Dialect"})
@Slf4j
class CheckControllerAllExceptionTest 
{
    @Container
    private static final MySQLContainer<?> MY_SQL_CONTAINER = new MySQLContainer<>("mysql:5.7.37").withDatabaseName("testdb").withUsername("mysql").withPassword("password");
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.datasource.url", MY_SQL_CONTAINER::getJdbcUrl);
        registry.add("spring.datasource.password", MY_SQL_CONTAINER::getPassword);
        registry.add("spring.datasource.username", MY_SQL_CONTAINER::getUsername);
    }
    
    @LocalServerPort
	private int port;   
    
    
    @Autowired
    private DataSourceHealthIndicator dataSourceHealthIndicator;       
    
	@Autowired
	private TestRestTemplate restTemplate;   
	
	@BeforeAll
	public static void setUp()
	{
		
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@BeforeEach
	public void stopTest()
	{

	}	
        
    @Test
    void checkAll() 
    {
    	
    	dataSourceHealthIndicator.setDataSource(DataSourceBuilder.create().build());
    	    	
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/check/all", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("\"name\": \"MySQL\""));
    	assertTrue(response.getBody().contains("\"statusCode\": 503"));
    	assertTrue(response.getBody().contains("\"message\": \"Error\""));
    	    	
    }      
        
}
