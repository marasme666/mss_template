package com.ibm.sec.healthcheckms.archunit;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.*;
import static com.tngtech.archunit.library.Architectures.layeredArchitecture;

@AnalyzeClasses(packages = "com.ibm.sec.healthcheckms", importOptions = ImportOption.DoNotIncludeTests.class)
class ArchUnitApplicationTest 
{

    /**
     * Annotations checks
     */
	@ArchTest
    void field_injection_not_use_autowired_annotation(JavaClasses classes) 
    {
        noFields()
                .should().beAnnotatedWith(Autowired.class)
                .check(classes);
    }

	@ArchTest
    void repository_classes_should_have_spring_repository_annotation(JavaClasses classes) 
    {
        classes()
                .that().resideInAPackage("..repository..")
                .should().beAnnotatedWith(Repository.class)
                .check(classes);
    }

	@ArchTest
    void service_classes_should_have_spring_service_annotation(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..service..")
                .should().beAnnotatedWith(Service.class)
                .check(classes);
    }

    /**
     * Package Dependency Checks
     */
	@ArchTest
    void services_and_repositories_should_not_depend_on_controller(JavaClasses classes)  
    {
        noClasses()
                .that().resideInAnyPackage("com.ibm.sec.healthcheckms.service..")
                .or().resideInAnyPackage("com.ibm.sec.healthcheckms.vms.repository..")
                .should()
                .dependOnClassesThat()
                .resideInAnyPackage("com.ibm.sec.healthcheckms.controller..")
                .because("Services and repositories should not depend on web layer")
                .check(classes);
    }

    /**
     * Class Dependency Checks
     */
	@ArchTest
    void service_classes_should_only_be_accessed_by_controller(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..service..")
                .should().onlyBeAccessed().byAnyPackage("..service..", "..controller..")
                .check(classes);
    }

	@ArchTest
    void repository_classes_should_only_be_accessed_by_service(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..repository..")
                .should().onlyBeAccessed().byAnyPackage("..repository..", "..service..")
                .check(classes);
    }

    /**
     * Naming convention
     */
	@ArchTest
    void service_classes_should_be_named_blabla_service(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..service..")
                .should().haveSimpleNameEndingWith("Service")
                .check(classes);
    }

	@ArchTest
    void repository_classes_should_be_named_blabla_repository(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..repository..")
                .should().haveSimpleNameEndingWith("Repository")
                .check(classes);
    }

	@ArchTest
    void controller_classes_should_be_named_blabla_controller(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..controller..")
                .should().haveSimpleNameEndingWith("Controller")
                .check(classes);
    }

    /**
     * Layer Dependency Rules Test
     */
	@ArchTest
    void layered_architecture_should_be_respected(JavaClasses classes)  
    {
        layeredArchitecture()
                .layer("Controller").definedBy("..controller..")
                .layer("Service").definedBy("..service..")
                .layer("Repository").definedBy("..repository..")

                .whereLayer("Controller").mayNotBeAccessedByAnyLayer()
                .whereLayer("Service").mayOnlyBeAccessedByLayers("Controller")
                .whereLayer("Repository").mayOnlyBeAccessedByLayers("Service")
                .check(classes);
    }

	@ArchTest
    void repositories_must_reside_in_repository_package(JavaClasses classes)  
    {
        classes().that()
                .haveNameMatching(".*Repository").should().resideInAPackage("..repository..")
                .as("Repositories should reside in a package '..repository..'")
                .check(classes);
    }

	@ArchTest
    void services_must_reside_in_service_package(JavaClasses classes)  
    {
        classes().that()
                .haveNameMatching(".*Service").should().resideInAPackage("..service..")
                .as("Services should reside in a package '..service..'")
                .check(classes);
    }

	@ArchTest
    void entity_classes_should_be_public(JavaClasses classes)  
    {
        classes()
                .that().resideInAPackage("..entities..")
                .should()
                .bePublic()
                .check(classes);
    }
}
