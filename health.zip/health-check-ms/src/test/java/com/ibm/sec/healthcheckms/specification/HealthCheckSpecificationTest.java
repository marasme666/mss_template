package com.ibm.sec.healthcheckms.specification;


import com.ibm.sec.healthcheckms.dto.HealthCheckSearch;
import com.ibm.sec.healthcheckms.vms.entities.HealthCheck;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

@SpringBootTest
class HealthCheckSpecificationTest {

    private CriteriaBuilder criteriaBuilderMock;

    private CriteriaQuery criteriaQueryMock;

    private Root<HealthCheck> healthCheckRootMock;

    @BeforeEach
    public void setUp() {
        criteriaBuilderMock = mock(CriteriaBuilder.class);
        criteriaQueryMock = mock(CriteriaQuery.class);
        healthCheckRootMock = mock(Root.class);
    }

    @Test
    void toPredicateForIds() {
        HealthCheckSearch filters = new HealthCheckSearch();
        List<Long> ids = new ArrayList<Long>();
        ids.add(1L);
        ids.add(2L);
        ids.add(3L);
        filters.setIds(ids);
        mock(Expression.class);
        Path path = mock(Path.class);

        when(healthCheckRootMock.get("id")).thenReturn(path);

        Predicate p = mock(Predicate.class);
        when(criteriaBuilderMock.disjunction()).thenReturn(p);
        Specification<HealthCheck> actual = new HealthCheckSpecification(filters);
        actual.toPredicate(healthCheckRootMock, criteriaQueryMock, criteriaBuilderMock);
        verify(healthCheckRootMock, times(1)).get("id");
    }

    @Test
    void toPredicateForNames() {
        HealthCheckSearch filters = new HealthCheckSearch();
        List<String> names = new ArrayList<String>();
        names.add("test");
        names.add("test2");
        names.add("test3");
        filters.setNames(names);
        mock(Expression.class);
        Path path = mock(Path.class);

        when(healthCheckRootMock.get("name")).thenReturn(path);

        Predicate p = mock(Predicate.class);
        when(criteriaBuilderMock.disjunction()).thenReturn(p);
        Specification<HealthCheck> actual = new HealthCheckSpecification(filters);
        actual.toPredicate(healthCheckRootMock, criteriaQueryMock, criteriaBuilderMock);
        verify(healthCheckRootMock, times(1)).get("name");
    }

    @Test
    void toPredicateForToolIds() {
        HealthCheckSearch filters = new HealthCheckSearch();
        List<Long> toolIds = new ArrayList<Long>();
        toolIds.add(1L);
        toolIds.add(2L);
        toolIds.add(3L);
        filters.setToolIds(toolIds);
        mock(Expression.class);
        Path path = mock(Path.class);

        when(healthCheckRootMock.get("toolId")).thenReturn(path);

        Predicate p = mock(Predicate.class);
        when(criteriaBuilderMock.disjunction()).thenReturn(p);
        Specification<HealthCheck> actual = new HealthCheckSpecification(filters);
        actual.toPredicate(healthCheckRootMock, criteriaQueryMock, criteriaBuilderMock);
        verify(healthCheckRootMock, times(1)).get("toolId");
    }

    @Test
    void toPredicateForSeverities() {
        HealthCheckSearch filters = new HealthCheckSearch();
        List<HealthCheck.HealthCheckSeverity> severities = new ArrayList<HealthCheck.HealthCheckSeverity>();
        severities.add(HealthCheck.HealthCheckSeverity.MEDIUM);
        severities.add(HealthCheck.HealthCheckSeverity.ALLOWED);
        severities.add(HealthCheck.HealthCheckSeverity.HIGH);
        severities.add(HealthCheck.HealthCheckSeverity.INFO);
        severities.add(HealthCheck.HealthCheckSeverity.UNKNOWN);
        filters.setSeverities(severities);
        mock(Expression.class);
        Path path = mock(Path.class);

        when(healthCheckRootMock.get("severity")).thenReturn(path);

        Predicate p = mock(Predicate.class);
        when(criteriaBuilderMock.disjunction()).thenReturn(p);
        Specification<HealthCheck> actual = new HealthCheckSpecification(filters);
        actual.toPredicate(healthCheckRootMock, criteriaQueryMock, criteriaBuilderMock);
        verify(healthCheckRootMock, times(1)).get("severity");
    }


}

