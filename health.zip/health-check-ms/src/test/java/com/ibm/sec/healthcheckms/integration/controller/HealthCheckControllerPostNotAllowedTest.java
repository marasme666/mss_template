package com.ibm.sec.healthcheckms.integration.controller;


import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;

@Tag("Integration")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Sql(scripts = {"classpath:database/schema.sql", "classpath:database/functional_health_check_tool_data.sql"})
@TestPropertySource(properties = {"spring.jpa.hibernate.ddl-auto=none", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL57Dialect", "rest.api.post.allowed=false"})
@Slf4j
class HealthCheckControllerPostNotAllowedTest 
{
    @Container
    private static final MySQLContainer<?> MY_SQL_CONTAINER = new MySQLContainer<>("mysql:5.7.37").withDatabaseName("testdb").withUsername("mysql").withPassword("password");
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.datasource.url", MY_SQL_CONTAINER::getJdbcUrl);
        registry.add("spring.datasource.password", MY_SQL_CONTAINER::getPassword);
        registry.add("spring.datasource.username", MY_SQL_CONTAINER::getUsername);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate;    
    
	@BeforeAll
	public static void setUp()
	{
		
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@BeforeEach
	public void stopTest()
	{

	}	
	
    //*******************************************
    // DATA POST TESTING
    //*******************************************		    
    @Test
    void addHealtCheckToDatabase() 
    {
    	// Verify if repository is empty
    	ResponseEntity<String> responseGet = restTemplate.getForEntity("http://localhost:"+port+"/health-check", String.class);
		 
    	assertEquals(HttpStatus.OK, responseGet.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(responseGet.getBody(), "$.items[*]");
    	
    	assertEquals(0, allItems.size()); 
    	

    	// add HealtCheck
    	String requestJson = "{\"name\":\"NAME_TEST_2\",\"toolId\":2, \"severity\":\"ALLOWED\"}";
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
    	
    	ResponseEntity<String> responsePost = restTemplate.exchange("http://localhost:"+port+"/health-check", HttpMethod.POST, entity, String.class);
    			 
    	assertEquals(HttpStatus.METHOD_NOT_ALLOWED, responsePost.getStatusCode());
    	
        	    	
    	// Verify if item has been added
    	ResponseEntity<String> responseGet1 = restTemplate.getForEntity("http://localhost:"+port+"/health-check", String.class);
		 
    	assertEquals(HttpStatus.OK, responseGet1.getStatusCode());
    	
    	System.out.println(responseGet1.getBody());
    	
    	List<Object> allItems1 = JsonPath.read(responseGet1.getBody(), "$.items[*]");
    	
    	assertEquals(0, allItems1.size());    	
    }  
    
}
