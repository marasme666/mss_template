package com.ibm.sec.healthcheckms.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.util.StreamUtils;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

@WebMvcTest(value = SwaggerController.class)
class SwaggerControllerTest {

    @Autowired
    private ResourceLoader resourceLoader;
    @Autowired
    MockMvc mockMvc;

    @Test
    void swaggerV2() throws Exception {
        Resource resource = resourceLoader.getResource("classpath:swagger.v2.yaml");
        StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/swagger").accept(MediaType.APPLICATION_JSON);
        mockMvc.perform(requestBuilder).andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();
    }
    
    @Test
    void swaggerV3() throws Exception {
        Resource resource = resourceLoader.getResource("classpath:swagger.v3.yaml");
        StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/swagger/v3").accept(MediaType.APPLICATION_JSON);
        mockMvc.perform(requestBuilder).andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();
    }    
}
