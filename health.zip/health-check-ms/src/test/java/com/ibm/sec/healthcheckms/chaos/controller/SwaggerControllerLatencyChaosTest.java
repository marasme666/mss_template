package com.ibm.sec.healthcheckms.chaos.controller;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import lombok.extern.slf4j.Slf4j;

@Tag("Chaos")
@ActiveProfiles("chaos-monkey")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Sql(scripts = {"classpath:database/schema.sql", "classpath:database/functional_health_check_tool_data.sql", "classpath:database/functional_health_check_data.sql"})
@TestPropertySource(properties = {"chaos.monkey.enabled=true", "chaos.monkey.watcher.rest-controller=true", "chaos.monkey.assaults.level=1", "chaos.monkey.assaults.latencyActive=true", "spring.jpa.hibernate.ddl-auto=none", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL57Dialect"})
@Slf4j
class SwaggerControllerLatencyChaosTest 
{
    @Container
    private static final MySQLContainer<?> MY_SQL_CONTAINER = new MySQLContainer<>("mysql:5.7.37").withDatabaseName("testdb").withUsername("mysql").withPassword("password");
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.datasource.url", MY_SQL_CONTAINER::getJdbcUrl);
        registry.add("spring.datasource.password", MY_SQL_CONTAINER::getPassword);
        registry.add("spring.datasource.username", MY_SQL_CONTAINER::getUsername);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate;   
	
	@BeforeAll
	public static void setUp()
	{
		
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@BeforeEach
	public void stopTest()
	{

	}	
    
	@RepeatedTest(5)  
    void swaggerV2() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/swagger", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("swagger:"));
    	
    	
    	ResponseEntity<String> response1 = restTemplate.getForEntity("http://localhost:"+port+"/swagger/", String.class);
		 
    	assertEquals(HttpStatus.OK, response1.getStatusCode());
    	assertTrue(response1.getBody().contains("swagger:"));
    	
    	
    	ResponseEntity<String> response2 = restTemplate.getForEntity("http://localhost:"+port+"/swagger/v2", String.class);
		 
    	assertEquals(HttpStatus.OK, response2.getStatusCode());
    	assertTrue(response2.getBody().contains("swagger:"));
    	
    }  
    
    
	@RepeatedTest(5)  
    void swaggerV3() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/swagger/v3", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	assertTrue(response.getBody().contains("openapi:"));
    	
    }      
    
}
