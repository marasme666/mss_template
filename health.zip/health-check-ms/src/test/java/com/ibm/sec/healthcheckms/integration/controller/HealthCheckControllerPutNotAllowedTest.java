package com.ibm.sec.healthcheckms.integration.controller;


import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import lombok.extern.slf4j.Slf4j;

@Tag("Integration")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Sql(scripts = {"classpath:database/schema.sql", "classpath:database/functional_health_check_tool_data.sql", "classpath:database/functional_health_check_data.sql"})
@TestPropertySource(properties = {"spring.jpa.hibernate.ddl-auto=none", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL57Dialect", "rest.api.put.allowed=false"})
@Slf4j
class HealthCheckControllerPutNotAllowedTest 
{
    @Container
    private static final MySQLContainer<?> MY_SQL_CONTAINER = new MySQLContainer<>("mysql:5.7.37").withDatabaseName("testdb").withUsername("mysql").withPassword("password");
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.datasource.url", MY_SQL_CONTAINER::getJdbcUrl);
        registry.add("spring.datasource.password", MY_SQL_CONTAINER::getPassword);
        registry.add("spring.datasource.username", MY_SQL_CONTAINER::getUsername);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate;    
    
	@BeforeAll
	public static void setUp()
	{
		
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@BeforeEach
	public void stopTest()
	{

	}	
	
    //*******************************************
    // DATA PUT TESTING
    //*******************************************	
    
    @Test
    void modifyHealtCheckNotExistedId() 
    {
       	// add HealtCheck
    	String requestJson = "{\"name\":\"NAME_TEST_PUT\",\"toolId\":2, \"severity\":\"UNKNOWN\"}";
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
    	
    	ResponseEntity<String> responsePut = restTemplate.exchange("http://localhost:"+port+"/health-check/0", HttpMethod.PUT, entity, String.class);    	
    	    	    			 
    	assertEquals(HttpStatus.METHOD_NOT_ALLOWED, responsePut.getStatusCode());	 
    } 	
	    
    @Test
    void modifyHealtCheckExistedId() 
    {
       	// add HealtCheck
    	String requestJson = "{\"name\":\"NAME_TEST_PUT\",\"toolId\":2, \"severity\":\"UNKNOWN\"}";
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
    	
    	ResponseEntity<String> responsePut = restTemplate.exchange("http://localhost:"+port+"/health-check/100", HttpMethod.PUT, entity, String.class);    	
    	    	    			 
    	assertEquals(HttpStatus.METHOD_NOT_ALLOWED, responsePut.getStatusCode());	    	    	
    }      
    
}
