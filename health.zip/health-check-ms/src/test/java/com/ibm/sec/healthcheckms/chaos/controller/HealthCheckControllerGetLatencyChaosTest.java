package com.ibm.sec.healthcheckms.chaos.controller;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInfo;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;


import com.jayway.jsonpath.JsonPath;

import lombok.extern.slf4j.Slf4j;

@Tag("Chaos")
@ActiveProfiles("chaos-monkey")
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Testcontainers
@Sql(scripts = {"classpath:database/schema.sql", "classpath:database/functional_health_check_tool_data.sql", "classpath:database/functional_health_check_data.sql"})
@TestPropertySource(properties = {"chaos.monkey.enabled=true", "chaos.monkey.watcher.rest-controller=true", "chaos.monkey.assaults.level=1", "chaos.monkey.assaults.latencyActive=true", "spring.jpa.hibernate.ddl-auto=none", "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL57Dialect"})
@Slf4j
class HealthCheckControllerGetLatencyChaosTest 
{
    @Container
    private static final MySQLContainer<?> MY_SQL_CONTAINER = new MySQLContainer<>("mysql:5.7.37").withDatabaseName("testdb").withUsername("mysql").withPassword("password");
    
    @DynamicPropertySource
    public static void setDatasourceProperties(final DynamicPropertyRegistry registry) 
    {
        registry.add("spring.datasource.url", MY_SQL_CONTAINER::getJdbcUrl);
        registry.add("spring.datasource.password", MY_SQL_CONTAINER::getPassword);
        registry.add("spring.datasource.username", MY_SQL_CONTAINER::getUsername);
    }
    
    @LocalServerPort
	private int port;    
    
	@Autowired
	private TestRestTemplate restTemplate;    
    
	@BeforeAll
	public static void setUp()
	{
		
	}
	
	@AfterAll
	public static void tearDown()
	{
		
	}	
	
	@BeforeEach
	public void startTest(TestInfo testInfo)
	{
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
		log.info("START TEST: " + testInfo.getDisplayName() );
		log.info("--------------------------------------------------");
		log.info("--------------------------------------------------");
	}
	
	@BeforeEach
	public void stopTest()
	{

	}	
	
    //*******************************************
    // DATA GET TESTING
    //*******************************************	
    
	@RepeatedTest(5)
    void healtCheckNotExistedId() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/0", String.class);
    			 
    	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());	 
    } 	
	
	@RepeatedTest(5)
    void healtCheckAllRows() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);     
    }     
    
    
	@RepeatedTest(5)
    void healtCheckOneRowAllowed() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/100", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	int healthCheckId = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals(100, healthCheckId);
    	
    	
    	String healthCheckName = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("HEALTH_CHECK_NAME_101", healthCheckName);    
    	
    	
    	int healthCheckToolId = JsonPath.read(response.getBody(), "$.toolId");
    	
    	assertEquals(1, healthCheckToolId);
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_1", healthCheckToolName);    	
    	
    	
    	String severity = JsonPath.read(response.getBody(), "$.severity");
    	
    	assertEquals("ALLOWED", severity); 
    }      
    
    
	@RepeatedTest(5)
    void healtCheckOneRowInfo() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/101", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	int healthCheckId = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals(101, healthCheckId);
    	
    	
    	String healthCheckName = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("HEALTH_CHECK_NAME_102", healthCheckName);    
    	
    	
    	int healthCheckToolId = JsonPath.read(response.getBody(), "$.toolId");
    	
    	assertEquals(2, healthCheckToolId);
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_2", healthCheckToolName);    	
    	
    	
    	String severity = JsonPath.read(response.getBody(), "$.severity");
    	
    	assertEquals("INFO", severity); 
    }   
    
	@RepeatedTest(5)
    void healtCheckOneRowLow() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/102", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode()) ;
    	
    	int healthCheckId = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals(102, healthCheckId);
    	
    	
    	String healthCheckName = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("HEALTH_CHECK_NAME_103", healthCheckName);    
    	
    	
    	int healthCheckToolId = JsonPath.read(response.getBody(), "$.toolId");
    	
    	assertEquals(3, healthCheckToolId);
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_3", healthCheckToolName);    	
    	
    	
    	String severity = JsonPath.read(response.getBody(), "$.severity");
    	
    	assertEquals("LOW", severity); 
    }   
    
    
	@RepeatedTest(5)
    void healtCheckOneRowMedium() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/103", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	int healthCheckId = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals(103, healthCheckId);
    	
    	
    	String healthCheckName = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("HEALTH_CHECK_NAME_104", healthCheckName);    
    	
    	
    	int healthCheckToolId = JsonPath.read(response.getBody(), "$.toolId");
    	
    	assertEquals(4, healthCheckToolId);
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_4", healthCheckToolName);      	
    	
    	
    	String severity = JsonPath.read(response.getBody(), "$.severity");
    	
    	assertEquals("MEDIUM", severity); 
    }    
    
	@RepeatedTest(5)
    void healtCheckOneRowHigh() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/104", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	int healthCheckId = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals(104, healthCheckId);
    	
    	
    	String healthCheckName = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("HEALTH_CHECK_NAME_105", healthCheckName);    
    	
    	
    	int healthCheckToolId = JsonPath.read(response.getBody(), "$.toolId");
    	
    	assertEquals(5, healthCheckToolId);
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_5", healthCheckToolName);      	
    	
    	
    	String severity = JsonPath.read(response.getBody(), "$.severity");
    	
    	assertEquals("HIGH", severity); 
    }  
    
    
	@RepeatedTest(5)
    void healtCheckOneRowUnknown() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check/105", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	int healthCheckId = JsonPath.read(response.getBody(), "$.id");
    	
    	assertEquals(105, healthCheckId);
    	
    	
    	String healthCheckName = JsonPath.read(response.getBody(), "$.name");
    	
    	assertEquals("HEALTH_CHECK_NAME_106", healthCheckName);    
    	
    	
    	int healthCheckToolId = JsonPath.read(response.getBody(), "$.toolId");
    	
    	assertEquals(6, healthCheckToolId);
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_6", healthCheckToolName);      	
    	
    	
    	String severity = JsonPath.read(response.getBody(), "$.severity");
    	
    	assertEquals("UNKNOWN", severity); 
    }  
    
    //*******************************************
    // PAGINATION TESTING
    //*******************************************
    
	@RepeatedTest(5)
    void healtCheckPaginationWithPage0() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?start=0&limit=6", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(6, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(2, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);     
    }      
    
    
	@RepeatedTest(5)
    void healtCheckPaginationWithPage1() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?start=1&limit=6", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(6, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(6, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(2, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(1, start);     	
    }
    
    //*******************************************
    // FILTER TESTING
    //*******************************************    
  
	@RepeatedTest(5)
    void healtCheckWithFilterIds() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?ids=100,101,102", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(3, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(3, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(3, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);  
    	
    	
    	int healtCheckId100 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals(100, healtCheckId100);  
    	
    	
    	int healtCheckId101 = JsonPath.read(response.getBody(), "$.items[1].id");
    	
    	assertEquals(101, healtCheckId101);
    	
    	
    	int healtCheckId102 = JsonPath.read(response.getBody(), "$.items[2].id");
    	
    	assertEquals(102, healtCheckId102);    	   	   	
    }   
    
    
	@RepeatedTest(5)
    void healtCheckWithFilterSeverities() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?severities=MEDIUM,HIGH", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(4, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(4, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(4, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);  
    	
    	
    	String severity0 = JsonPath.read(response.getBody(), "$.items[0].severity");
    	
    	assertEquals("MEDIUM", severity0);  
    	
    	
    	String severity1 = JsonPath.read(response.getBody(), "$.items[1].severity");
    	
    	assertEquals("HIGH", severity1); 
    	
    	
    	String severity2 = JsonPath.read(response.getBody(), "$.items[2].severity");
    	
    	assertEquals("MEDIUM", severity2);
    	
    	
    	String severity3 = JsonPath.read(response.getBody(), "$.items[3].severity");
    	
    	assertEquals("HIGH", severity3);     	    	    	
    }         
    
    
	@RepeatedTest(5)
    void healtCheckWithFilterNames() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?names=HEALTH_CHECK_NAME_104,HEALTH_CHECK_NAME_105", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode()) ;
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(2, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(2, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(2, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);  
    	
    	
    	String healthCheckName104 = JsonPath.read(response.getBody(), "$.items[0].name");
    	
    	assertEquals("HEALTH_CHECK_NAME_104", healthCheckName104);  
    	
    	
    	String healthCheckName105 = JsonPath.read(response.getBody(), "$.items[1].name");
    	
    	assertEquals("HEALTH_CHECK_NAME_105", healthCheckName105);  	    	
    }     
    
    
	@RepeatedTest(5)
    void healtCheckWithFilterToolIds() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?toolIds=7,8", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(2, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(2, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(2, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);  
    	
    	
    	int healthCheckToolId7 = JsonPath.read(response.getBody(), "$.items[0].toolId");
    	
    	assertEquals(7, healthCheckToolId7);  
    	
    	
    	int healthCheckToolId8 = JsonPath.read(response.getBody(), "$.items[1].toolId");
    	
    	assertEquals(8 , healthCheckToolId8); 
    	
    	
    	String healthCheckToolName7 = JsonPath.read(response.getBody(), "$.items[0].toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_7", healthCheckToolName7);   
    	
    	
    	String healthCheckToolName8 = JsonPath.read(response.getBody(), "$.items[1].toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_8", healthCheckToolName8);     	
    	
    	
    }    
    
    
	@RepeatedTest(5)
    void healtCheckWithTwoFiltersActive() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?ids=100,101&names=HEALTH_CHECK_NAME_103,HEALTH_CHECK_NAME_104", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(4, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(4, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(4, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);  
    	    	
    }     
    
    
    
	@RepeatedTest(5)
    void healtCheckWithAllFiltersActive() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?ids=100,101&names=HEALTH_CHECK_NAME_103,HEALTH_CHECK_NAME_104&severities=UNKNOWN,HIGH&toolIds=7,8", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(10, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(10, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(10, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);  
    	    	
    }    
    
    //*******************************************
    // SORTING TESTING
    //*******************************************
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckId() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=id", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);     
    	
    	
    	int healtCheckId100 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals(100, healtCheckId100);      	
    	
    }       
    
    
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckIdAsc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=id.ASC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);     
    	
    	
    	int healtCheckId100 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals(100, healtCheckId100);      	
    	
    }     
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckIdDesc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=id.DESC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);     
    	
    	
    	int healtCheckId111 = JsonPath.read(response.getBody(), "$.items[0].id");
    	
    	assertEquals(111, healtCheckId111);      	
    	
    }        
    
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckNameAsc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=name.ASC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);   
    	
    	
    	String healthCheckName101 = JsonPath.read(response.getBody(), "$.items[0].name");
    	
    	assertEquals("HEALTH_CHECK_NAME_101", healthCheckName101);      	
    	
    	   	
    	
    }     
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckNameDesc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=name.DESC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start); 
    	
    	
    	String healthCheckName112 = JsonPath.read(response.getBody(), "$.items[0].name");
    	
    	assertEquals("HEALTH_CHECK_NAME_112", healthCheckName112);      	
    	     	
    	
    }      
    
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckToolIdAsc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=toolId.ASC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);   
    	
    	
    	int healthCheckToolId1 = JsonPath.read(response.getBody(), "$.items[0].toolId");
    	
    	assertEquals(1, healthCheckToolId1);  
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.items[0].toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_1", healthCheckToolName);       	
    	

    }    
    
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortByHealthCheckToolIdDesc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=toolId.DESC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start); 
    	
    	
    	int healthCheckToolId12 = JsonPath.read(response.getBody(), "$.items[0].toolId");
    	
    	assertEquals(12, healthCheckToolId12);     	
    	
    	
    	String healthCheckToolName = JsonPath.read(response.getBody(), "$.items[0].toolName");
    	
    	assertEquals("HEALTH_CHECK_TOOL_NAME_12", healthCheckToolName);     	
    	     	
    	
    }            
    
    
          
    
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortBySeverityAsc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=severity.ASC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start);   
    	
    	
    	String severity0 = JsonPath.read(response.getBody(), "$.items[0].severity");
    	
    	assertEquals("ALLOWED", severity0);       	
    	
    }   
        
    
	@RepeatedTest(5)
    void healtCheckAllRowsSortBySeverityDesc() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?sort=severity.DESC", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	
    	
    	int totalCount = JsonPath.read(response.getBody(), "$.totalCount");
    	
    	assertEquals(12, totalCount);    
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start); 
    	
    	
    	String severity0 = JsonPath.read(response.getBody(), "$.items[0].severity");
    	
    	assertEquals("UNKNOWN", severity0);      	
    	     	
    	
    }    
    
    
    //*******************************************
    // EXCLUDE TOTAL ACCOUNT TESTING
    //*******************************************    
	@RepeatedTest(5)
    void healtCheckAllRowsExcludeTotalAccountTrue() 
    {
    	ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:"+port+"/health-check?excludeTotalCount=true", String.class);
    			 
    	assertEquals(HttpStatus.OK, response.getStatusCode());
    	
    	List<Object> allItems = JsonPath.read(response.getBody(), "$.items[*]");
    	
    	assertEquals(12, allItems.size());  
    	
    	
    	int limit = JsonPath.read(response.getBody(), "$.limit");
    	
    	assertEquals(12, limit);
    	 
    	
    	assertFalse(response.getBody().contains("totalCount"));
    	
    	
    	int totalPages = JsonPath.read(response.getBody(), "$.totalPages");
    	
    	assertEquals(1, totalPages);   
    	
    	
    	int start = JsonPath.read(response.getBody(), "$.start");
    	
    	assertEquals(0, start); 
    	    	     	
    	
    }          
    
}
