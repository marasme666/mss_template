package com.ibm.sec.healthcheckms.vms.entities;
import com.ibm.sec.healthcheckms.util.AssertAnnotations;
import com.ibm.sec.healthcheckms.util.ReflectTool;
import org.junit.jupiter.api.Test;

import javax.persistence.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HealthCheckTest {

    @Test
    void testTypeAnnotations() {
        AssertAnnotations.assertType(HealthCheck.class, Entity.class, Table.class);
    }

//    @Test
//    void testMethodAnnotations() {
//
//        AssertAnnotations.assertMethod(HealthCheck.class, "getId");
//        AssertAnnotations.assertMethod(HealthCheck.class, "getName");
//        AssertAnnotations.assertMethod(HealthCheck.class, "getToolId");
//        AssertAnnotations.assertMethod(HealthCheck.class, "getSeverity");
//    }

    @Test
    void testEntity() {
        // setup
        Entity e = ReflectTool.getClassAnnotation(HealthCheck.class, Entity.class);

        // assert
        assertEquals("", e.name());
    }
    @Test
    void testTable() {
        // setup
        Table t = ReflectTool.getClassAnnotation(HealthCheck.class, Table.class);

        // assert
        assertEquals("health_check", t.name());
    }

    @Test
    void testHealthCheckId() {
        // setup
        Column c = ReflectTool.getFieldAnnotation(HealthCheck.class, "id", Column.class);

        // assert
        assertEquals("health_check_id", c.name());
    }

    @Test
    void testHealthCheckName() {
        // setup
        Column c = ReflectTool.getFieldAnnotation(HealthCheck.class, "name", Column.class);

        // assert
        assertEquals("health_check_name", c.name());
    }
    @Test
    void testHealthCheckToolId() {
        // setup
        Column c = ReflectTool.getFieldAnnotation(HealthCheck.class, "toolId", Column.class);

        // assert
        assertEquals("health_check_tool_id", c.name());
    }
    @Test
    void testHealthCheckSeverity() {
        // setup
        Column c = ReflectTool.getFieldAnnotation(HealthCheck.class, "severity", Column.class);

        // assert
        assertEquals("severity", c.name());
    }

    @Test
    void testHelathCheckObject()
    {
        HealthCheck healthCheck  = new HealthCheck(1L, "test", HealthCheck.HealthCheckSeverity.ALLOWED, 1L);
        assertEquals(1, healthCheck.getId());
        assertEquals("test", healthCheck.getName());
        assertEquals(1, healthCheck.getToolId());
        assertEquals(HealthCheck.HealthCheckSeverity.ALLOWED, healthCheck.getSeverity());
    }
}
