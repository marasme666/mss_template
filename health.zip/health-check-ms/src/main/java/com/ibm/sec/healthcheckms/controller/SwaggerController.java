package com.ibm.sec.healthcheckms.controller;

import lombok.RequiredArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.sec.healthcheckms.exception.SwaggerNoFileFoundException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 *REST API microservice swagger controller - support v2 and v3 openapi
 */
@RestController
@RequestMapping("/swagger")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SwaggerController {
	
	private static final Logger logger = LoggerFactory.getLogger(SwaggerController.class);
    private final ResourceLoader resourceLoader;
    
    @Value("${swagger.v2.file.location}")
    private String swaggerV2FileLocation;
    
    @Value("${swagger.v3.file.location}")
    private String swaggerV3FileLocation;    

    @GetMapping({"","/","v2"})
    public String swaggerVersion2() {
    	
    	logger.info("Get Swagger v2 file");
    	
        Resource resource = resourceLoader.getResource(swaggerV2FileLocation);
        try 
        {
			return StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
		} 
        catch (IOException e) 
        {
        	throw new SwaggerNoFileFoundException();	
		}
    }
    
    @GetMapping({"v3"})
    public String swaggerVersion3() {
    	
    	logger.info("Get Swagger v3 file");
    	
        Resource resource = resourceLoader.getResource(swaggerV3FileLocation);
        try 
        {
			return StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
		} 
        catch (IOException e) 
        {
        	throw new SwaggerNoFileFoundException();	
		}
    }    
    
}

