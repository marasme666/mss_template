package com.ibm.sec.healthcheckms.exception;

public class SwaggerNoFileFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public SwaggerNoFileFoundException() {
        super("No Swagger file found");
    }		
}
