package com.ibm.sec.healthcheckms.vms.entities;


import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.AccessLevel;
import lombok.Getter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonUnwrapped;

import java.io.Serializable;

@Entity
@Getter
@RequiredArgsConstructor
@NoArgsConstructor(access=AccessLevel.PUBLIC, force=true)
@Table(name = "health_check")
public class HealthCheck implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "health_check_id")
    private final Long id;

	@NotNull(message = "The name must be defined")
	@Size(max = 255, message = "Name cannot exceed 255 characters")
    @Column(name = "health_check_name")
    private final String name;
		
	@NotNull(message = "The severity must be defined")
    @Column(name = "severity")
    @Enumerated(EnumType.STRING)
    private final HealthCheckSeverity severity;	

	@NotNull(message = "The tool id must be defined")
    @Column(name = "health_check_tool_id")
    private final Long toolId;
	
    @Setter
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "health_check_tool_id", referencedColumnName="health_check_tool_id", nullable = false, insertable=false, updatable=false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@JsonUnwrapped
	private HealthCheckTool healthCheckTool;	
	    
    public static enum HealthCheckSeverity {
        ALLOWED, INFO, LOW, MEDIUM, HIGH, UNKNOWN
    }    

}