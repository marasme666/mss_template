package com.ibm.sec.healthcheckms.service;

import com.ibm.sec.healthcheckms.dto.HealthCheckResponseDTO;
import com.ibm.sec.healthcheckms.dto.HealthCheckSearch;
import com.ibm.sec.healthcheckms.model.SessionDetail;
import com.ibm.sec.healthcheckms.specification.HealthCheckSpecification;
import com.ibm.sec.healthcheckms.vms.entities.HealthCheck;
import com.ibm.sec.healthcheckms.vms.repository.HealthCheckRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityNotFoundException;

/**
 * Logic to retrieve data from the database 
 */
@Service
public class HealthCheckService {

	private static final Logger logger = LoggerFactory.getLogger(HealthCheckService.class);
    private final HealthCheckRepository healthCheckRepository;	
	
    public HealthCheckService(HealthCheckRepository healthCheckRepository) 
    {
		this.healthCheckRepository = healthCheckRepository;
	}
    
    @Resource(name = "requestScopedBean")
    private SessionDetail requestScopedBean;    

    public HealthCheckResponseDTO retrieveHealthChecks(Integer pageNo, Integer pageSize, List<String> sortBy, Boolean excludeTotalCount,  HealthCheckSearch filters) {
    	logger.info(String.format("retrieveHealthChecks - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
    	Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(getSortedOrder(sortBy)));
        Page<HealthCheck> pageHealthCheck;
        if (filters.isEmpty()) {
            logger.info("filter not specified");
            pageHealthCheck = healthCheckRepository.findAll(paging);
        } else {
            logger.info("Retrieving data according to the specified filter");
            Specification<HealthCheck> healthCheckSpecification = new HealthCheckSpecification(filters);
            pageHealthCheck = healthCheckRepository.findAll(healthCheckSpecification, paging);
        }
        
        HealthCheckResponseDTO healthCheckResponseDTO = new HealthCheckResponseDTO();        
        healthCheckResponseDTO.setHealthChecks(pageHealthCheck.getContent());
        healthCheckResponseDTO.setStart(pageHealthCheck.getNumber());
        healthCheckResponseDTO.setTotalPages(pageHealthCheck.getTotalPages());
        if(Boolean.FALSE.equals(excludeTotalCount))
        {
        	healthCheckResponseDTO.setTotalCount(pageHealthCheck.getTotalElements());
        }        
        healthCheckResponseDTO.setLimit(pageHealthCheck.getNumberOfElements());
        		
        return healthCheckResponseDTO;
    }

    public HealthCheck retrieveHealthCheckById(Long id) {
    	logger.info(String.format("retrieveHealthCheckById - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
        return healthCheckRepository.findById(id).orElseThrow(() -> new EntityNotFoundException(String.valueOf(id)));
    }
    
    public void removeHealthCheckById(Long id) {
    	logger.info(String.format("removeHealthCheckById - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
    	if(!healthCheckRepository.existsById(id))
    	{
    		throw new EntityNotFoundException(String.valueOf(id));
    	}
    	
    	healthCheckRepository.deleteById(id);
    } 
    
    public HealthCheck addHealthCheck(HealthCheck healthCheck)
    {
    	logger.info(String.format("addHealthCheck - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
    	
    	HealthCheck healthCheckToSave = new HealthCheck(healthCheck.getId(), healthCheck.getName(), healthCheck.getSeverity(), healthCheck.getToolId());
    	
    	return healthCheckRepository.save(healthCheckToSave);
    }
    
    public HealthCheck editHealthCheck(Long id, HealthCheck healthCheck)
    {  
    	logger.info(String.format("editHealthCheck - call from user with SessionId: {} ", requestScopedBean.getThreadUuid()));
    	if(!healthCheckRepository.existsById(id))
    	{
    		throw new EntityNotFoundException(String.valueOf(id));
    	}
    	
    	HealthCheck healthCheckToUpdate = new HealthCheck(id, healthCheck.getName(), healthCheck.getSeverity(), healthCheck.getToolId());
    	
    	return healthCheckRepository.save(healthCheckToUpdate);
    }    
    
    
    private List<Sort.Order> getSortedOrder(List<String> sortByList) {
        List<Sort.Order> orders = new ArrayList<>();
        for (String sort : sortByList) {
            getSortingElements(sort, orders);
        }
        return orders;
    }    
        
    private List<Sort.Order> getSortingElements(String sortBy, List<Sort.Order> orders) {
        if (sortBy.contains(".ASC")) {
            sortBy = sortBy.replace(".ASC", "");
            orders.add(new Sort.Order(Sort.Direction.ASC, sortBy));
        } else if (sortBy.contains(".DESC")) {
            sortBy = sortBy.replace(".DESC", "");
            orders.add(new Sort.Order(Sort.Direction.DESC, sortBy));
        } else {
            orders.add(new Sort.Order(Sort.Direction.ASC, sortBy));
        }
        return orders;
    }    

}