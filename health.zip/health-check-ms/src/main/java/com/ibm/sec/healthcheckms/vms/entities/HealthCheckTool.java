package com.ibm.sec.healthcheckms.vms.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.BatchSize;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@BatchSize(size=100)
@Entity
@Getter
@RequiredArgsConstructor
@NoArgsConstructor(access=AccessLevel.PUBLIC, force=true)
@Table(name = "health_check_tool")
public class HealthCheckTool implements Serializable {
	
	private static final long serialVersionUID = 1L;
		
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "health_check_tool_id")
	@JsonIgnore
    private final Long id;	
	
	
	@NotNull(message = "The name must be defined")
	@Size(max = 255, message = "Tool name cannot exceed 255 characters")
    @Column(name = "health_check_tool_name")
    private final String toolName;	

}

