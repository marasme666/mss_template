package com.ibm.sec.healthcheckms.controller;

import lombok.RequiredArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.jdbc.DataSourceHealthIndicator;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST API microservice status controller
 */
@RestController
@RequestMapping("/health-check/check")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CheckController {
	
	private static final Logger logger = LoggerFactory.getLogger(CheckController.class);
	
	private final HealthEndpoint healthEndpoint;
	
	private final DataSourceHealthIndicator dataSourceHealthIndicator;
 
    /**
     * @return status
     */
    @GetMapping()
    public String check() {
    	
    	logger.info("Get Check Status");
    	
    	if (healthEndpoint.health().getStatus().equals(org.springframework.boot.actuate.health.Status.UP))
    	{
    		return "{ \"statusCode\": 200,  \"message\": \"Up\" }";
    	}
    	else
    	{
    		return "{ \"statusCode\": 503,  \"message\": \"Down\" }";
    	}
    }
    
    /**
     * @return detail status
     */
    @GetMapping({"/all"})
    public String checkAll() {
    	
    	logger.info("Get Check All Status");
    	    	
    	if (dataSourceHealthIndicator.health().getStatus().equals(org.springframework.boot.actuate.health.Status.UP))
    	{
    		return "{ \"statusItems\": [ { \"name\": \"MySQL\", \"statusCode\": 200, \"message\": \"Connected\" } ] }";
    	}
    	else
    	{
    		return "{ \"statusItems\": [ { \"name\": \"MySQL\", \"statusCode\": 503, \"message\": \"Error\" } ] }";
    	}    	
    }    
    
}

