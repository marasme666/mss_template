package com.ibm.sec.healthcheckms.exception;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.sec.healthcheckms.model.SessionDetail;

/**
 * Global class to handle different type of exceptions
 */
@ControllerAdvice
@RestController
public class GlobalExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    @Resource(name = "requestScopedBean")
    private SessionDetail requestScopedBean;      

    /**
     * Handle not found Id exception
     * @return NOT_FOUND status
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(javax.persistence.EntityNotFoundException.class)
    public ResponseEntity<String> handleHealthCheckNotFoundException(javax.persistence.EntityNotFoundException e) {
        logger.error("{} HealthCheckNotFoundException : {}" ,requestScopedBean.getThreadUuid(), e.getMessage());
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    
    /**
     * Handle lack of permission to execute particular method (GET, POST, PUT, DELETE)
     * @return METHOD_NOT_ALLOWED status
     */
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ExceptionHandler(MethodNotAllowedException.class)
    public ResponseEntity<String> handleMethodNotAllowedException(MethodNotAllowedException e) {
    	logger.error("{} HealthCheckMethodNotAllowedException : {}" ,requestScopedBean.getThreadUuid(), e.getMessage());
        return new ResponseEntity<>(HttpStatus.METHOD_NOT_ALLOWED);
    }    
    
    /**
     * Handle missing swagger file exception
     * @return NOT_FOUND status
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(SwaggerNoFileFoundException.class)
    public ResponseEntity<String> handleSwaggerExceptions(SwaggerNoFileFoundException e) {
    	logger.error("{} SwaggerException : {}" ,requestScopedBean.getThreadUuid(), e.getMessage());
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }    
}