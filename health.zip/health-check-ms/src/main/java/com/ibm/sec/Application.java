package com.ibm.sec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.context.annotation.RequestScope;

import com.ibm.sec.healthcheckms.model.SessionDetail;

/**
 * @version 1.x
 */
@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

    /**
     * @return Session Details 
     */
    @Bean
    @RequestScope
    public SessionDetail requestScopedBean() {
        return new SessionDetail();
    }	
	
}
