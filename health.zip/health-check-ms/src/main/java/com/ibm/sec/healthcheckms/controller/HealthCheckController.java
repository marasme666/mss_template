package com.ibm.sec.healthcheckms.controller;

import com.ibm.sec.healthcheckms.dto.HealthCheckResponseDTO;
import com.ibm.sec.healthcheckms.dto.HealthCheckSearch;
import com.ibm.sec.healthcheckms.exception.MethodNotAllowedException;
import com.ibm.sec.healthcheckms.service.HealthCheckService;
import com.ibm.sec.healthcheckms.vms.entities.HealthCheck;

import lombok.RequiredArgsConstructor;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST API microservice business logic controller - support CRUD operations
 */
@RestController
@RequestMapping("/health-check")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class HealthCheckController {

    private final HealthCheckService healthCheckService;
    private static final Logger logger = LoggerFactory.getLogger(HealthCheckController.class);
    
	@Value("${rest.api.get.allowed}")
	private boolean restApiGetAllowed;
	
	@Value("${rest.api.post.allowed}")
	private boolean restApiPostAllowed;	
	
	@Value("${rest.api.put.allowed}")
	private boolean restApiPutAllowed;	
	
	@Value("${rest.api.delete.allowed}")
	private boolean restApiDeleteAllowed;	
    
    @GetMapping("/{id}")
    public ResponseEntity<HealthCheck> getHealthCheckById(@PathVariable long id){
        logger.info("Retrieving record for id {}", id );
        if(!restApiGetAllowed)
        {
        	throw new MethodNotAllowedException();
        }
        return new ResponseEntity<>(healthCheckService.retrieveHealthCheckById(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<HealthCheckResponseDTO> getHealthChecks(@RequestParam(name = "start", defaultValue = "0") Integer pageNo,
                                                                  @RequestParam(name = "limit", defaultValue = "100") Integer pageSize,
                                                                  @RequestParam(name = "sort",  defaultValue = "id.ASC") List<String> sortBy,
                                                                  @RequestParam(name = "excludeTotalCount", defaultValue = "false") Boolean excludeTotalCount,
                                                                  HealthCheckSearch searchCriteria
    )
    {
    	logger.info("Retrieving all records");
        if(!restApiGetAllowed)
        {
        	throw new MethodNotAllowedException();
        }    	
    	HealthCheckResponseDTO healthCheckResponseDTO = healthCheckService.retrieveHealthChecks(pageNo, pageSize, sortBy, excludeTotalCount, searchCriteria );
        return new ResponseEntity<>(healthCheckResponseDTO, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable long id)
    {
        if(!restApiDeleteAllowed)
        {
        	throw new MethodNotAllowedException();
        }    	
    	logger.info("Delete record for id {}", id );
    	healthCheckService.removeHealthCheckById(id);
    }
    
    @PostMapping
    public ResponseEntity<HealthCheck> post(@Valid @RequestBody HealthCheck healthCheck)
    {   
        if(!restApiPostAllowed)
        {
        	throw new MethodNotAllowedException();
        }      	
    	logger.info("Create record");
    	return new ResponseEntity<>(healthCheckService.addHealthCheck(healthCheck), HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<HealthCheck> put(@PathVariable long id, @Valid @RequestBody HealthCheck healthCheck)
    {   
        if(!restApiPutAllowed)
        {
        	throw new MethodNotAllowedException();
        }      	
    	logger.info("Modify record for id {}", id );
    	return new ResponseEntity<>(healthCheckService.editHealthCheck(id, healthCheck), HttpStatus.OK);
    }    
    

}