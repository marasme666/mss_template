package com.ibm.sec.healthcheckms.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ibm.sec.healthcheckms.vms.entities.HealthCheck;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Health Check response object
 */
@Getter
@Setter
@NoArgsConstructor
public class HealthCheckResponseDTO {
    @JsonProperty("items")
    private  List<HealthCheck> healthChecks;
    
    @JsonProperty("limit")
    private  Integer limit;
    
    @JsonProperty("totalCount")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private  Long totalCount;
    
    @JsonProperty("totalPages")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private  Integer totalPages;
    
    @JsonProperty("start")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private  Integer start;
    
    public void setHealthChecks(List<HealthCheck> healthChecks)
    {
    	this.healthChecks = List.copyOf(healthChecks);
    }
    
}