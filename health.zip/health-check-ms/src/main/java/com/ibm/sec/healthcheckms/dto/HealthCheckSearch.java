package com.ibm.sec.healthcheckms.dto;



import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.ibm.sec.healthcheckms.vms.entities.HealthCheck.HealthCheckSeverity;


/**
 * Health Check filter request
 */
@NoArgsConstructor
public class HealthCheckSearch implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private boolean empty = true;
    private final List<Long> ids = new ArrayList<>();
    private final List<String> names = new ArrayList<>();
    private final List<HealthCheckSeverity> severities = new ArrayList<>();
    private final List<Long> toolIds = new ArrayList<>();
    
    public void setIds(final List<Long> ids)
    {
    	ids.stream().forEach(x-> {this.ids.add(x); this.empty=false;});
    }
    
    public void setNames(final List<String> names)
    {
    	names.stream().forEach(x-> {this.names.add(x); this.empty=false;});
    }    
    
    public void setSeverities(final List<HealthCheckSeverity> severities)
    {
    	severities.stream().forEach(x-> { this.severities.add(x); this.empty=false;});
    }    
    
    public void setToolIds(final List<Long> toolIds)
    {
    	toolIds.stream().forEach(x-> {this.toolIds.add(x); this.empty=false;});
    }   
    
    public boolean isEmpty()
    {
		return this.empty;   	
    }


	public List<Long> getIds() 
	{
		return Collections.unmodifiableList(ids);  
	}

	public List<String> getNames() 
	{
		return Collections.unmodifiableList(names); 
	}

	public List<HealthCheckSeverity> getSeverities() 
	{
		return Collections.unmodifiableList(severities); 
	}

	public List<Long> getToolIds() 
	{
		return Collections.unmodifiableList(toolIds);
	}

}