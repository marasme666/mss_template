package com.ibm.sec.healthcheckms.exception;

public class MethodNotAllowedException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public MethodNotAllowedException() {
        super("REST API Method Not Allowed");
    }		
}
