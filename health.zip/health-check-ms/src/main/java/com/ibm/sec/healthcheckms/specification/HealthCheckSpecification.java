package com.ibm.sec.healthcheckms.specification;

import com.ibm.sec.healthcheckms.dto.HealthCheckSearch;
import com.ibm.sec.healthcheckms.vms.entities.HealthCheck;

import org.apache.commons.lang3.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * Support dynamic filtering data 
 */
public class HealthCheckSpecification implements Specification<HealthCheck> {
	
	private static final long serialVersionUID = 1L;
	private transient HealthCheckSearch filter;
    private static final Logger logger = LoggerFactory.getLogger(HealthCheckSpecification.class);

    public HealthCheckSpecification( HealthCheckSearch filter) {
        super();
        this.filter = SerializationUtils.clone(filter);
    }


    public Predicate toPredicate(Root<HealthCheck> root, CriteriaQuery<?> cq, CriteriaBuilder cb) 
    {

        Predicate p = cb.disjunction();

        if (!filter.getIds().isEmpty()) 
        {
            logger.info("health_check ids filter is specified");
            p.getExpressions().add(root.get("id").in(filter.getIds()));
        }
        if (!filter.getNames().isEmpty())
        {
            logger.info("health_check names filter is specified");
            p.getExpressions().add(root.get("name").in(filter.getNames()));
        }
        if (!filter.getSeverities().isEmpty())
        {
            logger.info("health_check severities filter is specified");
            p.getExpressions().add(root.get("severity").in(filter.getSeverities()));
        }
        if (!filter.getToolIds().isEmpty())
        {
            logger.info("health_check tool ids filter is specified");
            p.getExpressions().add(root.get("toolId").in(filter.getToolIds()));
        }
        return p;
    }
}
