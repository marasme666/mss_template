package com.ibm.sec;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld 
{		
	
	@Value("${spring.application.name}")
	private String applicationName;	
	
	final MicroserviceAClient microserviceAClient;
	
	final MicroserviceBClient microserviceBClient;
	
	public HelloWorld( MicroserviceAClient microserviceAClient, MicroserviceBClient microserviceBClient) 
	{
		this.microserviceAClient = microserviceAClient;
		
		this.microserviceBClient = microserviceBClient;
	}

		
	@GetMapping("/")
	public String hello() 
	{				
      return "hello "+applicationName +" | "+ this.microserviceAClient.getMicroserviceAData() +" | "+ this.microserviceBClient.getMicroserviceBData();
	}
}
