package com.ibm.sec;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "microserviceAClient", url = "${microservice.a.get.baseUrl}")
public interface MicroserviceAClient 
{
    @GetMapping("/")
    String getMicroserviceAData();		
}
