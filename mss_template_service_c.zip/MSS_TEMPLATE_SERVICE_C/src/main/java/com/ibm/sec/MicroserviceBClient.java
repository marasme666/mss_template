package com.ibm.sec;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "microserviceBClient", url = "${microservice.b.get.baseUrl}")
public interface MicroserviceBClient 
{
    @GetMapping("/")
    String getMicroserviceBData();		
}
