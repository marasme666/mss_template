#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "-------------------------------"
echo "--- RUN: k8s_cicd_build.sh ---"
echo "-------------------------------"
echo "-------------------------------"

PLATFORM=$(uname)
if [[ "$PLATFORM" == 'Darwin' ]]; then
   cd ./bin && ./macos.sh && cd ..
fi

if [[ "$PLATFORM" == 'Linux' ]]; then
   cd ./bin && ./linux.sh && cd ..
fi

SCRIPT_PATH=$(pwd)
export PATH="${SCRIPT_PATH}/bin:$PATH"

echo "-------------------------------"
echo "---CONFIGURATION---"
echo "-------------------------------"
echo "kind version: " $(kind version) 
echo "kind path: " $(which kind)
echo "kubectl version: " $(kubectl version)  
echo "kubectl path: " $(which kubectl)
echo "skaffold version: " $(skaffold version) 
echo "skaffold path: " $(which skaffold)
echo "helm version: " $(helm version) 
echo "helm path: " $(which helm)
echo "docker version: " $(docker version) 
echo "docker path: " $(which docker)


#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#MICROSERVICE NAME 
MICROSERVICE_NAME=mss-template-service-c

#----------------------------------------------------------
# SET UP K8S CLUSTER
#----------------------------------------------------------

cd infra_gl
./k8s_infra_gl.sh ${MICROSERVICE_NAME}
cd ..

cd development
./k8s_infra_ms.sh ${MICROSERVICE_NAME}
./k8s_development.sh ${MICROSERVICE_NAME}
cd ..

#----------------------------------------------------------
# RUN AUTOMATIC TESTS
#----------------------------------------------------------
./k8s_test_all.sh ${MICROSERVICE_NAME}

#----------------------------------------------------------
# DESTROY K8S CLUSTER
#----------------------------------------------------------
./k8s_delete_cluster.sh ${MICROSERVICE_NAME}



 
