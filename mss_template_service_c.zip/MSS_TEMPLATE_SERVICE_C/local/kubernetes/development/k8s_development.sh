#!/bin/bash
set -o errexit

echo "-------------------------------"
echo "--- RUN: k8s_development.sh ---"
echo "-------------------------------"

#----------------------------------------------------------
#  GLOBAL VARIABLES
#----------------------------------------------------------

#CLUSTER NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
CLUSTER_NAME=${1:-local}

#MICROSERVICE NAME BY DEFAULT local (PASS ARGUMENT TO HAVE A DIFFRENT NAME)
MICROSERVICE_NAME=${2:-mss-template-service-c}

#SET UP TIMEOUT
DEFAULT_TIMEOUT=${3:-600s}

#KIND CLUSTER NAME
KIND_CLUSTER_NAME="kind-${CLUSTER_NAME}-cluster"

# GLOBAL INFRA RELEASE NAME - PLEASE NOT CHANGE IT
GL_HELM_RELEASE_INFRA_NAME=infra-gl

# MICROSERVICE INFRA RELEASE NAME - PLEASE NOT CHANGE IT
MS_HELM_RELEASE_INFRA_NAME=infra-ms-${MICROSERVICE_NAME}

#----------------------------------------------------------
# SET UP MICROSERVICE BUILD/DEPLOY
#----------------------------------------------------------

echo "--- GET K8S CLUSTER CONTEXT ---"

kubectl config use-context $KIND_CLUSTER_NAME

kubectl --context=$KIND_CLUSTER_NAME  wait --for=condition=ready pod --all --timeout=${DEFAULT_TIMEOUT}

echo "--- BUILD APPLICATION ---"

cd ../../../  

if [ ${CLUSTER_NAME} == "local" ]; then

  # run full build
  mvn clean package -Dmaven.test.skip=true
  
  # run sonarqube check
  mvn -Dmaven.test.failure.ignore=true -Dsonar.host.url=http://localhost:31400 -Dsonar.projectKey=${MICROSERVICE_NAME} -Dsonar.projectName=${MICROSERVICE_NAME} -Dsonar.login=sonarqube -Dsonar.password=password -Dsonar.dependencyCheck.reportPath=./dependency-check-report.xml -Dsonar.dependencyCheck.htmlReportPath=./dependency-check-report.html compile sonar:sonar 

else

  mvn clean package -Dmaven.test.skip=true

fi




MICROSERVICE_DOCKER_TAG_IMAGE=$(skaffold build | grep "Successfully tagged localhost/${MICROSERVICE_NAME}:" -m 1 | cut -d':' -f2)

echo "IMAGE TAG: $MICROSERVICE_DOCKER_TAG_IMAGE"

kind load docker-image localhost/${MICROSERVICE_NAME}:$MICROSERVICE_DOCKER_TAG_IMAGE  --name ${CLUSTER_NAME}-cluster

docker rmi localhost/${MICROSERVICE_NAME}:$MICROSERVICE_DOCKER_TAG_IMAGE

cd local/kubernetes/development


echo "--- UPDATE GITEA REPOSITORY---"

kubectl --context=$KIND_CLUSTER_NAME wait --for=condition=Ready pod -l app.kubernetes.io/name=gitea --timeout=${DEFAULT_TIMEOUT}

GITEA_POD_NAME=$(kubectl --context=$KIND_CLUSTER_NAME get pods --selector=app.kubernetes.io/instance=${GL_HELM_RELEASE_INFRA_NAME},app.kubernetes.io/name=gitea --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')


echo "--- UPDATE GITEA CHART REPOSITORY---"

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- rm -rf /tmp/${MICROSERVICE_NAME}

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME}  -- git clone http://gitea:password@localhost:3000/gitea/${MICROSERVICE_NAME}.git /tmp/${MICROSERVICE_NAME}

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- rm -rf /tmp/${MICROSERVICE_NAME}/charts && mkdir -p /tmp/${MICROSERVICE_NAME}/charts

kubectl --context=$KIND_CLUSTER_NAME cp ../../../chart ${GITEA_POD_NAME}:/tmp/${MICROSERVICE_NAME}/charts

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- /bin/sh -c " cd /tmp/${MICROSERVICE_NAME}/charts && git add . &&  git commit -m 'development' && git push origin master || true "


echo "--- UPDATE GITEA GITOPS REPOSITORY---"

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- rm -rf /tmp/gitops

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME}  -- git clone http://gitea:password@localhost:3000/gitea/gitops.git /tmp/gitops

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME}  -- rm -rf /tmp/gitops/${MICROSERVICE_NAME} && mkdir -p /tmp/gitops/${MICROSERVICE_NAME}

kubectl --context=$KIND_CLUSTER_NAME cp ../gitops ${GITEA_POD_NAME}:/tmp/gitops/${MICROSERVICE_NAME}

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- /bin/sh -c " cd /tmp/gitops/${MICROSERVICE_NAME} && sed -i -e 's/replaced_by_the_script_during_the_build/${MICROSERVICE_DOCKER_TAG_IMAGE}/g' gitops.yaml "

kubectl --context=$KIND_CLUSTER_NAME exec -it pod/${GITEA_POD_NAME} -- /bin/sh -c " cd /tmp/gitops/${MICROSERVICE_NAME} && git add . &&  git commit -m 'development' && git push origin master || true"

sleep 120

















